﻿# ==============================================================================
# PowerShell Remote Admin Tool - v3.0
# Dark Theme Edition - Redesigned
# ==============================================================================

#region INIT
if (-not (Get-Module -ListAvailable -Name ActiveDirectory)) {
    [System.Windows.Forms.MessageBox]::Show("Active Directory module not found.", "Error")
    exit
}
Import-Module ActiveDirectory
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

[System.Windows.Forms.Application]::EnableVisualStyles()

# Enable DPI awareness - prevents Windows from scaling/blurring the form
try {
    Add-Type -TypeDefinition @"
    using System;
    using System.Runtime.InteropServices;
    public class DPIHelper {
        [DllImport("user32.dll")]
        public static extern bool SetProcessDPIAware();
    }
"@
    [DPIHelper]::SetProcessDPIAware() | Out-Null
} catch { }
#endregion

# ==============================================================================
# THEME CONFIGURATION
# ==============================================================================
$theme = @{
    # Backgrounds
    BG             = [System.Drawing.Color]::FromArgb(22, 22, 30)
    BG_Secondary   = [System.Drawing.Color]::FromArgb(32, 32, 42)
    BG_Elevated    = [System.Drawing.Color]::FromArgb(42, 42, 56)
    BG_Input       = [System.Drawing.Color]::FromArgb(16, 16, 22)
    # Accent
    Accent         = [System.Drawing.Color]::FromArgb(78, 120, 255)
    AccentHover    = [System.Drawing.Color]::FromArgb(100, 142, 255)
    AccentDark     = [System.Drawing.Color]::FromArgb(55, 85, 200)
    AccentSubtle   = [System.Drawing.Color]::FromArgb(40, 50, 80)
    # Text
    TextPrimary    = [System.Drawing.Color]::FromArgb(225, 225, 240)
    TextSecondary  = [System.Drawing.Color]::FromArgb(130, 130, 160)
    TextDisabled   = [System.Drawing.Color]::FromArgb(70, 70, 95)
    TextMuted      = [System.Drawing.Color]::FromArgb(100, 100, 130)
    # Borders & Lines
    Border         = [System.Drawing.Color]::FromArgb(50, 50, 70)
    BorderLight    = [System.Drawing.Color]::FromArgb(60, 60, 82)
    # Semantic
    Success        = [System.Drawing.Color]::FromArgb(72, 200, 110)
    Warning        = [System.Drawing.Color]::FromArgb(255, 175, 55)
    ErrorColor     = [System.Drawing.Color]::FromArgb(255, 75, 75)
    InfoColor      = [System.Drawing.Color]::FromArgb(100, 160, 255)
    # Buttons
    ButtonBG       = [System.Drawing.Color]::FromArgb(44, 44, 62)
    ButtonBGHover  = [System.Drawing.Color]::FromArgb(58, 58, 82)
    ButtonBorder   = [System.Drawing.Color]::FromArgb(68, 68, 95)
    # Lists
    ListSelected   = [System.Drawing.Color]::FromArgb(50, 80, 170)
    ListAltRow     = [System.Drawing.Color]::FromArgb(20, 20, 28)
    ListHover      = [System.Drawing.Color]::FromArgb(36, 36, 50)
    # Status
    StatusBG       = [System.Drawing.Color]::FromArgb(14, 14, 20)
    # Fonts
    Font           = New-Object System.Drawing.Font("Segoe UI", 9)
    FontSmall      = New-Object System.Drawing.Font("Segoe UI", 8)
    FontBold       = New-Object System.Drawing.Font("Segoe UI", 9,  [System.Drawing.FontStyle]::Bold)
    FontTitle      = New-Object System.Drawing.Font("Segoe UI Semibold", 10)
    FontSection    = New-Object System.Drawing.Font("Segoe UI", 7.5, [System.Drawing.FontStyle]::Bold)
    FontMono       = New-Object System.Drawing.Font("Cascadia Code", 9)
    FontMonoSmall  = New-Object System.Drawing.Font("Cascadia Code", 8)
    FontHeader     = New-Object System.Drawing.Font("Segoe UI Semibold", 11)
}

# Fallback if Cascadia Code not installed
try {
    $testFont = New-Object System.Drawing.Font("Cascadia Code", 9)
    $testFont.Dispose()
} catch {
    $theme.FontMono      = New-Object System.Drawing.Font("Consolas", 9)
    $theme.FontMonoSmall = New-Object System.Drawing.Font("Consolas", 8)
}

# ==============================================================================
# TOOLTIP PROVIDER
# ==============================================================================
$script:toolTip             = New-Object System.Windows.Forms.ToolTip
$script:toolTip.BackColor   = $theme.BG_Elevated
$script:toolTip.ForeColor   = $theme.TextPrimary
$script:toolTip.InitialDelay = 400
$script:toolTip.ReshowDelay  = 200
$script:toolTip.OwnerDraw    = $false

# ==============================================================================
# STATE
# ==============================================================================
$csvPath           = Join-Path $PSScriptRoot "buttons.csv"
$historyFilePath   = Join-Path $PSScriptRoot "search_history.txt"
$favoritesFilePath = Join-Path $PSScriptRoot "favorites.txt"
$settingsFilePath  = Join-Path $PSScriptRoot "settings.json"

# ==============================================================================
# SETTINGS DEFAULTS & LOAD/SAVE
# ==============================================================================
$script:settingsDefaults = @{
    Search = @{
        MinAutoSearchChars = 2
        DebounceMs         = 500
        SearchBase         = ""          # OU distinguished name, empty = entire domain
        MaxResults         = 100
        AutoSearchEnabled  = $true       # Auto-search while typing
    }
    Ping = @{
        RepeatIntervalMs   = 3000
        TimeoutMs          = 1500
        AutoRepeat         = $true
        SoundOnStatusChange = $false
    }
    Appearance = @{
        AccentPreset       = "Blue"      # Blue, Green, Purple, Orange, Red, Teal
        FontSize           = 9
        AlwaysOnTop        = $false
        LockPosition       = $true
    }
    RDP = @{
        Fullscreen         = $true
        AdminSession       = $false
        MultiMon           = $false
        CustomWidth        = 0           # 0 = default/fullscreen
        CustomHeight       = 0
    }
    Restart = @{
        DelaySeconds       = 0           # 0 = immediate
        ShowMessage        = $false
        DefaultMessage     = "This computer will restart shortly. Please save your work."
    }
    Paths = @{
        DameWarePath       = "C:\Program Files (x86)\DameWare Development\DameWare Mini Remote Control\DWRCC.exe"
        PsExecPath         = "C:\Tools\PsExec.exe"
        IconsFolder        = "Icons"
    }
    Logon = @{
        AutoRefresh        = $false
        RefreshIntervalSec = 30          # seconds between auto-refreshes
    }
    Layout = @{
        ButtonWidth        = 222
        ButtonHeight       = 48
        ButtonColumns      = 2
    }
    Behavior = @{
        RememberLastComputer = $true
        LastComputer         = ""        # auto-saved, not user-editable
        LastWindowX          = -1        # -1 = use CenterScreen
        LastWindowY          = -1
    }
    Shortcuts = @{
        Search             = "Ctrl+F"
        Ping               = "Ctrl+P"
        RDP                = "Ctrl+R"
        CShare             = "Ctrl+E"
    }
    History = @{
        MaxItems           = 50
        AutoClearDays      = 0           # 0 = never
    }
}

function Clone-Hashtable {
    param($Source)
    $clone = @{}
    foreach ($key in $Source.Keys) {
        if ($Source[$key] -is [hashtable]) {
            $clone[$key] = Clone-Hashtable $Source[$key]
        } else {
            $clone[$key] = $Source[$key]
        }
    }
    return $clone
}

function Load-Settings {
    $script:settings = Clone-Hashtable $script:settingsDefaults
    if (Test-Path $settingsFilePath) {
        try {
            $json = Get-Content $settingsFilePath -Raw -ErrorAction Stop | ConvertFrom-Json
            # Merge loaded values over defaults (preserves new defaults if JSON is older version)
            foreach ($category in $script:settingsDefaults.Keys) {
                if ($json.PSObject.Properties.Name -contains $category) {
                    foreach ($key in $script:settingsDefaults[$category].Keys) {
                        $val = $json.$category.$key
                        if ($null -ne $val) {
                            # ConvertFrom-Json turns booleans into proper bools, numbers into ints/doubles
                            $script:settings[$category][$key] = $val
                        }
                    }
                }
            }
        } catch {
            Write-Warning "Failed to load settings: $($_.Exception.Message). Using defaults."
        }
    }
}

function Save-Settings {
    try {
        # Build a clean ordered object for JSON
        $obj = [ordered]@{}
        foreach ($category in ($script:settings.Keys | Sort-Object)) {
            $catObj = [ordered]@{}
            foreach ($key in ($script:settings[$category].Keys | Sort-Object)) {
                $catObj[$key] = $script:settings[$category][$key]
            }
            $obj[$category] = $catObj
        }
        $obj | ConvertTo-Json -Depth 4 | Set-Content $settingsFilePath -Encoding UTF8
    } catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Failed to save settings:`n$($_.Exception.Message)",
            "Settings Error", "OK", "Error")
    }
}

# Load on startup
Load-Settings

# Apply accent color from settings
$accentPresets = @{
    "Blue"   = @{ Accent = [System.Drawing.Color]::FromArgb(78, 120, 255);  Hover = [System.Drawing.Color]::FromArgb(100, 142, 255); Dark = [System.Drawing.Color]::FromArgb(55, 85, 200);   Subtle = [System.Drawing.Color]::FromArgb(40, 50, 80) }
    "Green"  = @{ Accent = [System.Drawing.Color]::FromArgb(72, 200, 110);  Hover = [System.Drawing.Color]::FromArgb(92, 220, 130);  Dark = [System.Drawing.Color]::FromArgb(50, 160, 80);   Subtle = [System.Drawing.Color]::FromArgb(35, 60, 45) }
    "Purple" = @{ Accent = [System.Drawing.Color]::FromArgb(155, 89, 255);  Hover = [System.Drawing.Color]::FromArgb(175, 115, 255); Dark = [System.Drawing.Color]::FromArgb(120, 60, 210);  Subtle = [System.Drawing.Color]::FromArgb(55, 40, 80) }
    "Orange" = @{ Accent = [System.Drawing.Color]::FromArgb(255, 150, 50);  Hover = [System.Drawing.Color]::FromArgb(255, 175, 80);  Dark = [System.Drawing.Color]::FromArgb(200, 115, 30);  Subtle = [System.Drawing.Color]::FromArgb(70, 55, 35) }
    "Red"    = @{ Accent = [System.Drawing.Color]::FromArgb(255, 85, 85);   Hover = [System.Drawing.Color]::FromArgb(255, 110, 110); Dark = [System.Drawing.Color]::FromArgb(200, 55, 55);   Subtle = [System.Drawing.Color]::FromArgb(70, 40, 40) }
    "Teal"   = @{ Accent = [System.Drawing.Color]::FromArgb(50, 200, 180);  Hover = [System.Drawing.Color]::FromArgb(75, 220, 200);  Dark = [System.Drawing.Color]::FromArgb(35, 160, 140);  Subtle = [System.Drawing.Color]::FromArgb(30, 60, 55) }
}
$selectedAccent = $script:settings.Appearance.AccentPreset
if ($accentPresets.ContainsKey($selectedAccent) -and $selectedAccent -ne "Blue") {
    $ap = $accentPresets[$selectedAccent]
    $theme.Accent       = $ap.Accent
    $theme.AccentHover  = $ap.Hover
    $theme.AccentDark   = $ap.Dark
    $theme.AccentSubtle = $ap.Subtle
}

# Apply font size from settings
$customFontSize = $script:settings.Appearance.FontSize
if ($customFontSize -ne 9) {
    $theme.Font       = New-Object System.Drawing.Font("Segoe UI", $customFontSize)
    $theme.FontSmall  = New-Object System.Drawing.Font("Segoe UI", ($customFontSize - 1))
    $theme.FontBold   = New-Object System.Drawing.Font("Segoe UI", $customFontSize, [System.Drawing.FontStyle]::Bold)
    $theme.FontTitle  = New-Object System.Drawing.Font("Segoe UI Semibold", ($customFontSize + 1))
    $theme.FontHeader = New-Object System.Drawing.Font("Segoe UI Semibold", ($customFontSize + 2))
}

# Apply loaded settings to variables that were set before settings existed
$script:minAutoSearchChars = $script:settings.Search.MinAutoSearchChars
$script:selectedComputer   = $null
$script:cachedButtonPanels = @{}
$script:lastSearchText     = ""
$script:defaultStatus      = "Ready  |  $($script:settings.Shortcuts.Search): Search  |  $($script:settings.Shortcuts.Ping): Ping  |  $($script:settings.Shortcuts.RDP): RDP  |  $($script:settings.Shortcuts.CShare): C$"
$script:pingTask           = $null
$script:pinger             = $null
$script:pingTarget         = ""

# Info fetch async state
$script:infoFetchPS        = $null
$script:infoFetchHandle    = $null
$script:infoFetchTarget    = ""

# Logon rows cache (parallel to listbox items - holds raw session objects)
$script:logonRows          = @()

# WMI scriptblock that runs in background runspace
$script:infoFetchScript = {
    param([string]$ComputerName)
    $result = @{
        IPAddress  = "N/A"; MACAddress = "N/A"; LinkSpeed = "N/A"
        DiskSize   = "N/A"; DiskFree   = "N/A"; DiskPct  = "N/A"
        OS         = "N/A"; RAM        = "N/A"; CPU      = "N/A"
        Model      = "N/A"; Error      = $null
    }
    try {
        # IP via DNS (fast)
        try {
            $addrs = [System.Net.Dns]::GetHostAddresses($ComputerName) |
                     Where-Object { $_.AddressFamily -eq 'InterNetwork' }
            if ($addrs) { $result.IPAddress = ($addrs | Select-Object -First 1).IPAddressToString }
        } catch { }

        # MAC + IP from WMI adapter config (also gets real IP for multi-NIC)
        $adapterCfg = Get-WmiObject -ComputerName $ComputerName -Class Win32_NetworkAdapterConfiguration `
                       -Filter "IPEnabled = True" -ErrorAction SilentlyContinue
        if ($adapterCfg) {
            $first = $adapterCfg | Select-Object -First 1
            if ($first.MACAddress)  { $result.MACAddress = $first.MACAddress }
            if ($first.IPAddress -and $first.IPAddress.Count -gt 0) {
                $ipv4 = $first.IPAddress | Where-Object { $_ -match '^\d{1,3}\.\d{1,3}' } | Select-Object -First 1
                if ($ipv4) { $result.IPAddress = $ipv4 }
            }
        }

        # Link speed from physical adapter
        $adapters = Get-WmiObject -ComputerName $ComputerName -Class Win32_NetworkAdapter `
                     -Filter "NetEnabled = True" -ErrorAction SilentlyContinue
        if ($adapters) {
            $fastest = $adapters | Where-Object { $_.Speed -gt 0 } | Sort-Object Speed -Descending | Select-Object -First 1
            if ($fastest) {
                if ($fastest.Speed -ge 1000000000) {
                    $result.LinkSpeed = "$([math]::Round($fastest.Speed / 1000000000, 1)) Gb/s"
                } elseif ($fastest.Speed -gt 0) {
                    $result.LinkSpeed = "$([math]::Round($fastest.Speed / 1000000, 0)) Mb/s"
                }
            }
        }

        # Disk C:
        $disk = Get-WmiObject -ComputerName $ComputerName -Class Win32_LogicalDisk `
                 -Filter "DeviceID='C:'" -ErrorAction SilentlyContinue
        if ($disk) {
            $sizeGB = [math]::Round($disk.Size     / 1GB, 0)
            $freeGB = [math]::Round($disk.FreeSpace / 1GB, 1)
            $pct    = if ($disk.Size -gt 0) { [math]::Round(($disk.FreeSpace / $disk.Size) * 100, 0) } else { 0 }
            $result.DiskSize = "$sizeGB GB"
            $result.DiskFree = "$freeGB GB"
            $result.DiskPct  = "$pct%"
        }

        # Computer system (model + RAM)
        $cs = Get-WmiObject -ComputerName $ComputerName -Class Win32_ComputerSystem -ErrorAction SilentlyContinue
        if ($cs) {
            $result.RAM   = "$([math]::Round($cs.TotalPhysicalMemory / 1GB, 0)) GB"
            $result.Model = $cs.Model
        }

        # OS
        $os = Get-WmiObject -ComputerName $ComputerName -Class Win32_OperatingSystem -ErrorAction SilentlyContinue
        if ($os) {
            $result.OS = $os.Caption -replace "Microsoft ", ""
        }

        # CPU
        $cpu = Get-WmiObject -ComputerName $ComputerName -Class Win32_Processor -ErrorAction SilentlyContinue |
               Select-Object -First 1
        if ($cpu) {
            # Shorten common CPU strings for display
            $cpuName = $cpu.Name -replace '\(R\)', '' -replace '\(TM\)', '' -replace '\s{2,}', ' '
            $result.CPU = $cpuName.Trim()
        }

    } catch {
        $result.Error = $_.Exception.Message
    }
    return $result
}

# ==============================================================================
# ASYNC PING CHECK (non-blocking)
# ==============================================================================
$script:pingCheckTimer          = New-Object System.Windows.Forms.Timer
$script:pingCheckTimer.Interval = 150

# Repeating interval timer - fires every 3s to kick off the next ping
$script:pingRepeatTimer          = New-Object System.Windows.Forms.Timer
$script:pingRepeatTimer.Interval = $script:settings.Ping.RepeatIntervalMs
$script:pingRepeatTimer.Add_Tick({
    if ($script:selectedComputer) {
        Start-AsyncPing -ComputerName $script:selectedComputer
    } else {
        $script:pingRepeatTimer.Stop()
    }
})

$script:pingCheckTimer.Add_Tick({
    if ($null -eq $script:pingTask) {
        $script:pingCheckTimer.Stop()
        return
    }
    if (-not $script:pingTask.IsCompleted) { return }

    # Task completed - read result
    $script:pingCheckTimer.Stop()
    $target = $script:pingTarget
    try {
        $reply   = $script:pingTask.Result
        $online  = ($reply.Status -eq [System.Net.NetworkInformation.IPStatus]::Success)
        $latency = $reply.RoundtripTime
    } catch {
        $online  = $false
        $latency = 0
    }

    # Only update UI if this ping is still relevant (user didn't switch computers)
    if ($target -eq $script:selectedComputer) {
        # Detect status change for sound notification
        $previousText = $script:selectedComputerLabel.Text
        $wasOnline    = $previousText -notmatch 'OFFLINE' -and $previousText -notmatch '\[\.\.\.\]'

        if ($online) {
            $script:selectedComputerLabel.ForeColor = $theme.Success
            $script:selectedComputerLabel.Text      = "> $target  (${latency}ms)"
            $script:statusComputer.ForeColor        = $theme.Success
            $script:statusComputer.Text             = "Target: $target  (${latency}ms)  "
        } else {
            $script:selectedComputerLabel.ForeColor = $theme.ErrorColor
            $script:selectedComputerLabel.Text      = "> $target  (OFFLINE)"
            $script:statusComputer.ForeColor        = $theme.ErrorColor
            $script:statusComputer.Text             = "Target: $target  (OFFLINE)  "
        }

        # Sound on status change
        if ($script:settings.Ping.SoundOnStatusChange -and $previousText -notmatch '\[\.\.\.\]') {
            if ($online -and -not $wasOnline) {
                [System.Media.SystemSounds]::Beep.Play()
            } elseif (-not $online -and $wasOnline) {
                [System.Media.SystemSounds]::Exclamation.Play()
            }
        }

        # Schedule next ping if auto-repeat is enabled
        if ($script:settings.Ping.AutoRepeat) {
            $script:pingRepeatTimer.Stop()
            $script:pingRepeatTimer.Start()
        }
    }

    # Cleanup
    if ($script:pinger) { $script:pinger.Dispose(); $script:pinger = $null }
    $script:pingTask = $null
})

# ==============================================================================
# ASYNC INFO FETCH TIMER (polls background runspace every 200ms)
# ==============================================================================
$script:infoFetchTimer          = New-Object System.Windows.Forms.Timer
$script:infoFetchTimer.Interval = 200
$script:infoFetchTimer.Add_Tick({
    if ($null -eq $script:infoFetchHandle) { $script:infoFetchTimer.Stop(); return }
    if (-not $script:infoFetchHandle.IsCompleted) { return }

    $script:infoFetchTimer.Stop()
    $target = $script:infoFetchTarget

    try {
        $resultCollection = $script:infoFetchPS.EndInvoke($script:infoFetchHandle)
        $info = $resultCollection[0]
    } catch {
        $info = @{ Error = $_.Exception.Message }
    }

    if ($target -eq $script:selectedComputer) {
        if ($info.Error) {
            $script:infoStatusLabel.Text      = "Error fetching data"
            $script:infoStatusLabel.ForeColor = $theme.ErrorColor
            $script:toolTip.SetToolTip($script:infoStatusLabel, $info.Error)
        } else {
            $script:infoStatusLabel.Text      = "Updated: $(Get-Date -Format 'HH:mm:ss')"
            $script:infoStatusLabel.ForeColor = $theme.TextDisabled
            $script:toolTip.SetToolTip($script:infoStatusLabel, "")
        }

        # Update network labels
        $script:infoIPLabel.Text   = $info.IPAddress
        $script:infoMACLabel.Text  = $info.MACAddress
        $script:infoLinkLabel.Text = $info.LinkSpeed
        $script:toolTip.SetToolTip($script:infoIPLabel,   $info.IPAddress)
        $script:toolTip.SetToolTip($script:infoMACLabel,  $info.MACAddress)

        # Update storage labels
        $script:infoDiskSizeLabel.Text = $info.DiskSize
        $script:infoDiskFreeLabel.Text = $info.DiskFree
        $script:infoDiskPctLabel.Text  = $info.DiskPct

        # Color disk free percentage (red < 10%, orange < 20%, green otherwise)
        if ($info.DiskPct -and $info.DiskPct -ne "N/A") {
            $pctNum = [int]($info.DiskPct -replace '[^0-9]', '')
            $script:infoDiskPctLabel.ForeColor = if ($pctNum -lt 10) { $theme.ErrorColor } `
                                                  elseif ($pctNum -lt 20) { $theme.Warning } `
                                                  else { $theme.Success }
        }

        # Update system labels
        $script:infoOSLabel.Text    = $info.OS
        $script:infoRAMLabel.Text   = $info.RAM
        $script:infoCPULabel.Text   = $info.CPU
        $script:infoModelLabel.Text = $info.Model
        $script:toolTip.SetToolTip($script:infoOSLabel,    $info.OS)
        $script:toolTip.SetToolTip($script:infoCPULabel,   $info.CPU)
        $script:toolTip.SetToolTip($script:infoModelLabel, $info.Model)
    }

    # Cleanup runspace
    if ($script:infoFetchPS) { $script:infoFetchPS.Dispose(); $script:infoFetchPS = $null }
    $script:infoFetchHandle = $null
})

# ==============================================================================
# ASYNC LOGON FETCH TIMER
# ==============================================================================
$script:logonFetchPS     = $null
$script:logonFetchHandle = $null
$script:logonFetchTarget = ""

$script:logonFetchScript = {
    param([string]$ComputerName)
    $result = @{ Rows = @(); Error = $null }
    try {
        # quser.exe may return non-zero exit code when no sessions exist
        $raw = quser.exe /server:$ComputerName 2>$null
        if (-not $raw -or $raw.Count -lt 2) { return $result }

        # quser output is fixed-width. Read column start positions from the header line.
        # Header example:
        #  USERNAME              SESSIONNAME        ID  STATE   IDLE TIME  LOGON TIME
        $header = $raw[0]

        function Get-ColStart {
            param([string]$H, [string]$Name)
            return $H.IndexOf($Name)
        }

        $colUsername    = 0
        $colSessionName = Get-ColStart $header "SESSIONNAME"
        $colID          = Get-ColStart $header " ID"
        $colState       = Get-ColStart $header "STATE"
        $colIdle        = Get-ColStart $header "IDLE TIME"
        $colLogon       = Get-ColStart $header "LOGON TIME"

        # Helper: safely extract a fixed-width slice from a line
        function Get-Field {
            param([string]$Line, [int]$Start, [int]$End)
            if ($Start -lt 0 -or $Start -ge $Line.Length) { return "" }
            $len = [Math]::Min($End, $Line.Length) - $Start
            if ($len -le 0) { return "" }
            return $Line.Substring($Start, $len).Trim()
        }

        foreach ($line in ($raw | Select-Object -Skip 1)) {
            if ([string]::IsNullOrWhiteSpace($line)) { continue }

            # Pad line to full header width so substring never throws on short lines
            $padded = $line.PadRight($header.Length)

            $username    = (Get-Field $padded $colUsername    $colSessionName) -replace '^>', ''
            $sessionName =  Get-Field $padded $colSessionName $colID
            $id          =  Get-Field $padded $colID          $colState
            $state       =  Get-Field $padded $colState       $colIdle
            # LOGON TIME runs to end of line
            $logonRaw    = if ($colLogon -ge 0 -and $colLogon -lt $padded.Length) {
                               $padded.Substring($colLogon).Trim()
                           } else { "" }

            # Parse and reformat logon time to dd/MM/yyyy  HH:mm
            $logonDisplay = $logonRaw
            if ($logonRaw) {
                try {
                    $parsed       = [datetime]::Parse($logonRaw)
                    $logonDisplay = $parsed.ToString("dd/MM/yyyy  HH:mm")
                } catch {
                    $logonDisplay = $logonRaw
                }
            }

            $result.Rows += [PSCustomObject]@{
                Username    = $username.Trim()
                SessionName = $sessionName.Trim()
                SessionID   = $id.Trim()
                State       = $state.Trim()
                LogonTime   = $logonDisplay
            }
        }
    } catch {
        $result.Error = $_.Exception.Message
    }
    return $result
}

$script:logonFetchTimer          = New-Object System.Windows.Forms.Timer
$script:logonFetchTimer.Interval = 200
$script:logonFetchTimer.Add_Tick({
    if ($null -eq $script:logonFetchHandle) { $script:logonFetchTimer.Stop(); return }
    if (-not $script:logonFetchHandle.IsCompleted) { return }

    $script:logonFetchTimer.Stop()
    $target = $script:logonFetchTarget

    try {
        $resultCollection = $script:logonFetchPS.EndInvoke($script:logonFetchHandle)
        $info = $resultCollection[0]
    } catch {
        $info = @{ Rows = @(); Error = $_.Exception.Message }
    }

    if ($target -eq $script:selectedComputer) {
        $script:logonUsersListBox.Items.Clear()
        $script:logonRows = @()

        if ($info.Error) {
            $script:logonStatusLabel.Text      = "Error: $($info.Error)"
            $script:logonStatusLabel.ForeColor = $theme.ErrorColor
            $script:logonUsersListBox.Items.Add("[Error querying sessions]")
        } elseif ($info.Rows.Count -eq 0) {
            $script:logonStatusLabel.Text      = "No active sessions"
            $script:logonStatusLabel.ForeColor = $theme.TextDisabled
            $script:logonUsersListBox.Items.Add("[No logged-on users]")
        } else {
            $script:logonStatusLabel.Text      = "$($info.Rows.Count) session(s)  |  Updated: $(Get-Date -Format 'HH:mm:ss')"
            $script:logonStatusLabel.ForeColor = $theme.TextDisabled
            foreach ($row in $info.Rows) {
                $stateIcon = if ($row.State -match '^Active') { "[A]" } else { "[D]" }
                $logon     = if ($row.LogonTime) { "  |  $($row.LogonTime)" } else { "" }
                $display   = "$stateIcon  $($row.Username)$logon"
                $script:logonUsersListBox.Items.Add($display) | Out-Null
                $script:logonRows += $row   # keep raw object for context menu
            }
        }
    }

    if ($script:logonFetchPS) { $script:logonFetchPS.Dispose(); $script:logonFetchPS = $null }
    $script:logonFetchHandle = $null
})

function Start-LogonFetch {
    param([string]$ComputerName)

    $script:logonFetchTimer.Stop()
    if ($script:logonFetchPS) {
        try { $script:logonFetchPS.Stop() } catch { }
        $script:logonFetchPS.Dispose()
        $script:logonFetchPS = $null
    }
    $script:logonFetchHandle = $null
    $script:logonFetchTarget = $ComputerName

    $script:logonUsersListBox.Items.Clear()
    $script:logonUsersListBox.Items.Add("[Loading sessions...]") | Out-Null
    $script:logonStatusLabel.Text      = "Querying..."
    $script:logonStatusLabel.ForeColor = $theme.TextMuted

    try {
        $script:logonFetchPS = [System.Management.Automation.PowerShell]::Create()
        $script:logonFetchPS.AddScript($script:logonFetchScript).AddArgument($ComputerName) | Out-Null
        $script:logonFetchHandle = $script:logonFetchPS.BeginInvoke()
        $script:logonFetchTimer.Start()
    } catch {
        $script:logonStatusLabel.Text      = "Failed to start query"
        $script:logonStatusLabel.ForeColor = $theme.ErrorColor
    }
}

# ==============================================================================
# LOGON AUTO-REFRESH TIMER
# ==============================================================================
$script:logonAutoRefreshTimer          = New-Object System.Windows.Forms.Timer
$script:logonAutoRefreshTimer.Interval = [Math]::Max(10000, $script:settings.Logon.RefreshIntervalSec * 1000)
$script:logonAutoRefreshTimer.Add_Tick({
    if ($script:selectedComputer -and $script:settings.Logon.AutoRefresh) {
        Start-LogonFetch -ComputerName $script:selectedComputer
    } else {
        $script:logonAutoRefreshTimer.Stop()
    }
})

function Start-InfoFetch {
    param([string]$ComputerName)

    # Cancel any in-flight fetch
    $script:infoFetchTimer.Stop()
    if ($script:infoFetchPS) {
        try { $script:infoFetchPS.Stop() } catch { }
        $script:infoFetchPS.Dispose()
        $script:infoFetchPS = $null
    }
    $script:infoFetchHandle = $null
    $script:infoFetchTarget = $ComputerName

    # Update header label immediately
    $script:infoComputerLabel.Text      = $ComputerName
    $script:infoComputerLabel.ForeColor = $theme.Accent

    # Reset all value labels to "loading" state
    $loadingText = "Loading..."
    $script:infoIPLabel.Text        = $loadingText
    $script:infoMACLabel.Text       = $loadingText
    $script:infoLinkLabel.Text      = $loadingText
    $script:infoDiskSizeLabel.Text  = $loadingText
    $script:infoDiskFreeLabel.Text  = $loadingText
    $script:infoDiskPctLabel.Text   = "..."
    $script:infoDiskPctLabel.ForeColor = $theme.TextMuted
    $script:infoOSLabel.Text        = $loadingText
    $script:infoRAMLabel.Text       = $loadingText
    $script:infoCPULabel.Text       = $loadingText
    $script:infoModelLabel.Text     = $loadingText
    $script:infoStatusLabel.Text    = "Fetching data..."
    $script:infoStatusLabel.ForeColor = $theme.TextMuted

    try {
        $script:infoFetchPS = [System.Management.Automation.PowerShell]::Create()
        $script:infoFetchPS.AddScript($script:infoFetchScript).AddArgument($ComputerName) | Out-Null
        $script:infoFetchHandle = $script:infoFetchPS.BeginInvoke()
        $script:infoFetchTimer.Start()
    } catch {
        $script:infoStatusLabel.Text      = "Failed to start fetch"
        $script:infoStatusLabel.ForeColor = $theme.ErrorColor
        $script:toolTip.SetToolTip($script:infoStatusLabel, $_.Exception.Message)
    }
}


$script:searchTimer          = New-Object System.Windows.Forms.Timer
$script:searchTimer.Interval = $script:settings.Search.DebounceMs
$script:searchTimer.Add_Tick({
    $script:searchTimer.Stop()
    Invoke-ComputerSearch
})

function Start-AsyncPing {
    param([string]$ComputerName)
    # Cancel any in-flight ping and pending repeat
    $script:pingRepeatTimer.Stop()
    $script:pingCheckTimer.Stop()
    if ($script:pinger) { $script:pinger.Dispose(); $script:pinger = $null }
    $script:pingTask   = $null
    $script:pingTarget = $ComputerName

    try {
        $script:pinger   = New-Object System.Net.NetworkInformation.Ping
        $script:pingTask = $script:pinger.SendPingAsync($ComputerName, $script:settings.Ping.TimeoutMs)
        $script:pingCheckTimer.Start()
    } catch {
        # SendPingAsync failed immediately (bad hostname etc.)
        $script:selectedComputerLabel.ForeColor = $theme.ErrorColor
        $script:selectedComputerLabel.Text      = "> $ComputerName  (OFFLINE)"
        $script:statusComputer.ForeColor        = $theme.ErrorColor
        $script:statusComputer.Text             = "Target: $ComputerName  (OFFLINE)  "
        if ($script:pinger) { $script:pinger.Dispose(); $script:pinger = $null }
    }
}

# ==============================================================================
# HELPER: Escape LDAP special characters
# ==============================================================================
function Escape-LDAPFilter {
    param([string]$Value)
    $Value = $Value -replace '\\', '\5c'
    $Value = $Value -replace '\*',  '\2a'
    $Value = $Value -replace '\(',  '\28'
    $Value = $Value -replace '\)',  '\29'
    $Value = $Value -replace '\x00','\00'
    return $Value
}

# ==============================================================================
# HELPERS: Themed Controls
# ==============================================================================
function New-ThemedLabel {
    param(
        [string]$Text, [int]$X, [int]$Y,
        [switch]$Bold, [switch]$Secondary, [switch]$Title, [switch]$Section
    )
    $lbl           = New-Object System.Windows.Forms.Label
    $lbl.Text      = $Text
    $lbl.Location  = New-Object System.Drawing.Point($X, $Y)
    $lbl.AutoSize  = $true
    $lbl.BackColor = [System.Drawing.Color]::Transparent

    if ($Section) {
        $lbl.ForeColor = $theme.TextMuted
        $lbl.Font      = $theme.FontSection
    } elseif ($Secondary) {
        $lbl.ForeColor = $theme.TextSecondary
        $lbl.Font      = $theme.Font
    } elseif ($Title) {
        $lbl.ForeColor = $theme.Accent
        $lbl.Font      = $theme.FontTitle
    } elseif ($Bold) {
        $lbl.ForeColor = $theme.TextPrimary
        $lbl.Font      = $theme.FontBold
    } else {
        $lbl.ForeColor = $theme.TextPrimary
        $lbl.Font      = $theme.Font
    }
    return $lbl
}

function New-ThemedTextBox {
    param([int]$X, [int]$Y, [int]$W = 220, [int]$H = 26)
    $tb             = New-Object System.Windows.Forms.TextBox
    $tb.Location    = New-Object System.Drawing.Point($X, $Y)
    $tb.Size        = New-Object System.Drawing.Size($W, $H)
    $tb.BackColor   = $theme.BG_Input
    $tb.ForeColor   = $theme.TextPrimary
    $tb.BorderStyle = 'FixedSingle'
    $tb.Font        = $theme.FontMono
    return $tb
}

function New-ThemedButton {
    param(
        [string]$Text, [int]$X, [int]$Y,
        [int]$W = 85, [int]$H = 28,
        [switch]$Accent, [switch]$Danger, [switch]$Small,
        [string]$Tooltip = ""
    )
    $btn                           = New-Object System.Windows.Forms.Button
    $btn.Text                      = $Text
    $btn.Location                  = New-Object System.Drawing.Point($X, $Y)
    $btn.Size                      = New-Object System.Drawing.Size($W, $H)
    $btn.FlatStyle                 = 'Flat'
    $btn.Font                      = if ($Small) { $theme.FontSmall } else { $theme.FontBold }
    $btn.Cursor                    = [System.Windows.Forms.Cursors]::Hand
    $btn.FlatAppearance.BorderSize = 1

    if ($Accent) {
        $btn.BackColor                  = $theme.Accent
        $btn.ForeColor                  = [System.Drawing.Color]::White
        $btn.FlatAppearance.BorderColor = $theme.AccentDark
    } elseif ($Danger) {
        $btn.BackColor                  = $theme.ErrorColor
        $btn.ForeColor                  = [System.Drawing.Color]::White
        $btn.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(200, 50, 50)
    } else {
        $btn.BackColor                  = $theme.ButtonBG
        $btn.ForeColor                  = $theme.TextPrimary
        $btn.FlatAppearance.BorderColor = $theme.ButtonBorder
    }

    $colorNormal = $btn.BackColor
    $colorHover  = if ($Accent) { $theme.AccentHover } elseif ($Danger) { [System.Drawing.Color]::FromArgb(255, 100, 100) } else { $theme.ButtonBGHover }
    $colorPress  = if ($Accent) { $theme.AccentDark  } elseif ($Danger) { [System.Drawing.Color]::FromArgb(180, 40, 40) } else { $theme.BG_Input }

    $btn.Add_MouseEnter({ $this.BackColor = $colorHover  }.GetNewClosure())
    $btn.Add_MouseLeave({ $this.BackColor = $colorNormal }.GetNewClosure())
    $btn.Add_MouseDown( { $this.BackColor = $colorPress  }.GetNewClosure())
    $btn.Add_MouseUp(   { $this.BackColor = $colorHover  }.GetNewClosure())

    if ($Tooltip) { $script:toolTip.SetToolTip($btn, $Tooltip) }

    return $btn
}

function New-ThemedListBox {
    param([int]$X, [int]$Y, [int]$W, [int]$H, [string]$SelectionMode = 'One')
    $lb               = New-Object System.Windows.Forms.ListBox
    $lb.Location      = New-Object System.Drawing.Point($X, $Y)
    $lb.Size          = New-Object System.Drawing.Size($W, $H)
    $lb.BackColor     = $theme.BG_Input
    $lb.ForeColor     = $theme.TextPrimary
    $lb.BorderStyle   = 'FixedSingle'
    $lb.Font          = $theme.FontMono
    $lb.SelectionMode = $SelectionMode
    $lb.DrawMode      = 'OwnerDrawFixed'
    $lb.ItemHeight    = 24

    $lb.Add_DrawItem({
        param($s, $e)
        if ($e.Index -lt 0) { return }

        $isSelected = ($e.State -band [System.Windows.Forms.DrawItemState]::Selected)
        $bgColor = if ($isSelected) {
            $theme.ListSelected
        } elseif ($e.Index % 2 -eq 0) {
            $theme.BG_Input
        } else {
            $theme.ListAltRow
        }
        $fgColor = if ($isSelected) { [System.Drawing.Color]::White } else { $theme.TextPrimary }

        # FIX: Dispose GDI objects properly
        $bgBrush = New-Object System.Drawing.SolidBrush($bgColor)
        $fgBrush = New-Object System.Drawing.SolidBrush($fgColor)
        try {
            $e.Graphics.FillRectangle($bgBrush, $e.Bounds)
            $pt = New-Object System.Drawing.PointF(($e.Bounds.X + 8), ($e.Bounds.Y + 4))
            $e.Graphics.DrawString($s.Items[$e.Index].ToString(), $theme.FontMono, $fgBrush, $pt)
            if ($isSelected) { $e.DrawFocusRectangle() }
        } finally {
            $bgBrush.Dispose()
            $fgBrush.Dispose()
        }
    })
    return $lb
}

function New-Separator {
    param([int]$X, [int]$Y, [int]$W, $Parent)
    $sep           = New-Object System.Windows.Forms.Panel
    $sep.Location  = New-Object System.Drawing.Point($X, $Y)
    $sep.Size      = New-Object System.Drawing.Size($W, 1)
    $sep.BackColor = $theme.Border
    $Parent.Controls.Add($sep)
    return $sep
}

function New-ThemedContextMenu {
    $cms                  = New-Object System.Windows.Forms.ContextMenuStrip
    $cms.BackColor        = $theme.BG_Elevated
    $cms.ForeColor        = $theme.TextPrimary
    $cms.Font             = $theme.Font
    $cms.ShowImageMargin  = $false   # removes the white left margin strip
    $cms.ShowCheckMargin  = $false
    # Use professional renderer so BackColor is actually respected
    $cms.Renderer         = New-Object System.Windows.Forms.ToolStripProfessionalRenderer(
        [System.Windows.Forms.ProfessionalColorTable]::new()
    )
    return $cms
}

function Add-ThemedMenuItem {
    param($Menu, [string]$Text)
    $item             = New-Object System.Windows.Forms.ToolStripMenuItem($Text)
    $item.BackColor   = $theme.BG_Elevated
    $item.ForeColor   = $theme.TextPrimary
    $item.Font        = $theme.Font
    $Menu.Items.Add($item) | Out-Null
    return $item
}

function New-InfoRow {
    param([string]$Label, [int]$Y, $Parent)
    $keyLabel           = New-Object System.Windows.Forms.Label
    $keyLabel.Text      = $Label
    $keyLabel.Location  = New-Object System.Drawing.Point(12, $Y)
    $keyLabel.Size      = New-Object System.Drawing.Size(75, 18)
    $keyLabel.Font      = $theme.FontSmall
    $keyLabel.ForeColor = $theme.TextSecondary
    $keyLabel.BackColor = [System.Drawing.Color]::Transparent
    $Parent.Controls.Add($keyLabel)

    $valLabel           = New-Object System.Windows.Forms.Label
    $valLabel.Text      = [char]0x2014  # em-dash placeholder
    $valLabel.Location  = New-Object System.Drawing.Point(90, $Y)
    $valLabel.Size      = New-Object System.Drawing.Size(183, 18)
    $valLabel.AutoSize  = $false
    $valLabel.Font      = $theme.FontMonoSmall
    $valLabel.ForeColor = $theme.TextPrimary
    $valLabel.BackColor = [System.Drawing.Color]::Transparent
    $Parent.Controls.Add($valLabel)

    $script:toolTip.SetToolTip($valLabel, "")
    return $valLabel
}

function Set-Status {
    param([string]$Message, [string]$Level = "Info")
    $color = switch ($Level) {
        "Success" { $theme.Success    }
        "Warning" { $theme.Warning    }
        "Error"   { $theme.ErrorColor }
        default   { $theme.TextSecondary }
    }
    $prefix = switch ($Level) {
        "Success" { "[OK] "  }
        "Warning" { "[!] "   }
        "Error"   { "[ERR] " }
        default   { ""       }
    }
    $script:statusLabel.Text      = "  $prefix$Message"
    $script:statusLabel.ForeColor = $color
}

function Start-RDPSession {
    param([string]$ComputerName)
    if ([string]::IsNullOrWhiteSpace($ComputerName)) {
        [System.Windows.Forms.MessageBox]::Show("Select a computer first.", "No Target", "OK", "Warning")
        return
    }
    $args = @("/v:$ComputerName")
    $rdp  = $script:settings.RDP
    if ($rdp.AdminSession)  { $args += "/admin" }
    if ($rdp.MultiMon)      { $args += "/multimon" }
    if (-not $rdp.Fullscreen -and $rdp.CustomWidth -gt 0 -and $rdp.CustomHeight -gt 0) {
        $args += "/w:$($rdp.CustomWidth)"
        $args += "/h:$($rdp.CustomHeight)"
    } elseif ($rdp.Fullscreen) {
        $args += "/f"
    }
    Start-Process "mstsc.exe" -ArgumentList ($args -join " ")
}

function Start-DameWareSession {
    param([string]$ComputerName)
    if ([string]::IsNullOrWhiteSpace($ComputerName)) {
        [System.Windows.Forms.MessageBox]::Show("Select a computer first.", "No Target", "OK", "Warning")
        return
    }
    $dwPath = $script:settings.Paths.DameWarePath
    if (Test-Path $dwPath) {
        Start-Process cmd.exe -ArgumentList "/c start `"`" `"$dwPath`" -m:$ComputerName -a:1"
    } else {
        [System.Windows.Forms.MessageBox]::Show("DameWare not found at:`n$dwPath`n`nUpdate the path in Settings > Paths.", "Not Found", "OK", "Warning")
    }
}

# ==============================================================================
# FUNCTION: Rebuild Button Panels (reload CSV into middle panel)
# ==============================================================================
function Rebuild-ButtonPanels {
    # Remove existing button panels from middlePanel
    $toRemove = @($middlePanel.Controls | Where-Object { $_.Tag -eq "ButtonPanel" })
    foreach ($ctrl in $toRemove) {
        $middlePanel.Controls.Remove($ctrl)
        $ctrl.Dispose()
    }
    $script:cachedButtonPanels = @{}

    if (Test-Path $csvPath) {
        $mainButtonPanel = New-ButtonPanel -PanelCsvFile "buttons.csv"
        if ($mainButtonPanel) {
            $middlePanel.Controls.Add($mainButtonPanel)
            $script:cachedButtonPanels["main"] = $mainButtonPanel
        }
        $mainButtonConfig = Import-Csv -Path $csvPath -ErrorAction SilentlyContinue
        if ($mainButtonConfig) {
            $mainButtonConfig |
                Where-Object { $_.Type -eq "OpenSubMenu" } |
                Select-Object -ExpandProperty Action -Unique |
                ForEach-Object {
                    if (-not $script:cachedButtonPanels.ContainsKey($_)) {
                        $subPanel = New-ButtonPanel -PanelCsvFile $_
                        if ($subPanel) {
                            $middlePanel.Controls.Add($subPanel)
                            $script:cachedButtonPanels[$_] = $subPanel
                        }
                    }
                }
        }
        Switch-ToPanel -PanelName "main"
    }
    Set-Status "Buttons reloaded from CSV" "Success"
}

# ==============================================================================
# FUNCTION: Button Settings Editor GUI
# ==============================================================================
function Show-ButtonEditor {
    $editorForm               = New-Object System.Windows.Forms.Form
    $editorForm.Text          = "Button Settings Editor"
    $editorForm.Size          = New-Object System.Drawing.Size(920, 620)
    $editorForm.StartPosition = 'CenterParent'
    $editorForm.BackColor     = $theme.BG
    $editorForm.ForeColor     = $theme.TextPrimary
    $editorForm.Font          = $theme.Font
    $editorForm.FormBorderStyle = 'FixedDialog'
    $editorForm.MaximizeBox   = $false
    $editorForm.MinimizeBox   = $false
    $editorForm.ShowInTaskbar = $false

    # Title label
    $titleLabel           = New-Object System.Windows.Forms.Label
    $titleLabel.Text      = "BUTTON CONFIGURATION"
    $titleLabel.Font      = $theme.FontHeader
    $titleLabel.ForeColor = $theme.Accent
    $titleLabel.AutoSize  = $true
    $titleLabel.Location  = New-Object System.Drawing.Point(14, 12)
    $titleLabel.BackColor = [System.Drawing.Color]::Transparent
    $editorForm.Controls.Add($titleLabel)

    $subtitleLabel           = New-Object System.Windows.Forms.Label
    $subtitleLabel.Text      = "Edit buttons loaded from buttons.csv  |  Changes are saved immediately to file"
    $subtitleLabel.Font      = $theme.FontSmall
    $subtitleLabel.ForeColor = $theme.TextSecondary
    $subtitleLabel.AutoSize  = $true
    $subtitleLabel.Location  = New-Object System.Drawing.Point(14, 36)
    $subtitleLabel.BackColor = [System.Drawing.Color]::Transparent
    $editorForm.Controls.Add($subtitleLabel)

    # Separator
    $edSep           = New-Object System.Windows.Forms.Panel
    $edSep.Location  = New-Object System.Drawing.Point(14, 56)
    $edSep.Size      = New-Object System.Drawing.Size(878, 1)
    $edSep.BackColor = $theme.Border
    $editorForm.Controls.Add($edSep)

    # ---- DataGridView ----
    $dgv                              = New-Object System.Windows.Forms.DataGridView
    $dgv.Location                     = New-Object System.Drawing.Point(14, 64)
    $dgv.Size                         = New-Object System.Drawing.Size(878, 440)
    $dgv.BackgroundColor              = $theme.BG_Input
    $dgv.GridColor                    = $theme.Border
    $dgv.BorderStyle                  = 'None'
    $dgv.CellBorderStyle              = 'SingleHorizontal'
    $dgv.ColumnHeadersBorderStyle     = 'Single'
    $dgv.RowHeadersVisible            = $true
    $dgv.RowHeadersWidth              = 35
    $dgv.AllowUserToResizeRows        = $false
    $dgv.AllowUserToAddRows           = $false
    $dgv.SelectionMode                = 'FullRowSelect'
    $dgv.MultiSelect                  = $false
    $dgv.Font                         = $theme.Font
    $dgv.RowTemplate.Height           = 30
    $dgv.AutoSizeColumnsMode          = 'None'
    $dgv.EnableHeadersVisualStyles    = $false
    $dgv.DefaultCellStyle.BackColor   = $theme.BG_Input
    $dgv.DefaultCellStyle.ForeColor   = $theme.TextPrimary
    $dgv.DefaultCellStyle.SelectionBackColor = $theme.ListSelected
    $dgv.DefaultCellStyle.SelectionForeColor = [System.Drawing.Color]::White
    $dgv.DefaultCellStyle.Font        = $theme.Font
    $dgv.ColumnHeadersDefaultCellStyle.BackColor = $theme.BG_Elevated
    $dgv.ColumnHeadersDefaultCellStyle.ForeColor = $theme.TextPrimary
    $dgv.ColumnHeadersDefaultCellStyle.Font      = $theme.FontBold
    $dgv.ColumnHeadersDefaultCellStyle.Alignment = 'MiddleLeft'
    $dgv.ColumnHeadersHeight          = 34
    $dgv.RowHeadersDefaultCellStyle.BackColor = $theme.BG_Secondary
    $dgv.RowHeadersDefaultCellStyle.ForeColor = $theme.TextSecondary

    # Columns
    $colText           = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $colText.HeaderText = "Button Text"
    $colText.Name       = "ButtonText"
    $colText.Width      = 140
    $dgv.Columns.Add($colText) | Out-Null

    $colAction           = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $colAction.HeaderText = "Action (Command / Script Path)"
    $colAction.Name       = "Action"
    $colAction.Width      = 400
    $dgv.Columns.Add($colAction) | Out-Null

    $colType           = New-Object System.Windows.Forms.DataGridViewComboBoxColumn
    $colType.HeaderText = "Type"
    $colType.Name       = "Type"
    $colType.Width      = 130
    $colType.FlatStyle  = 'Flat'
    $colType.Items.AddRange(@("CMD", "PowerShell", "PS-NewWindow", "CMD-Close", "OpenSubMenu", "ShowMainMenu"))
    $colType.DisplayStyle = 'DropDownButton'
    $dgv.Columns.Add($colType) | Out-Null

    $colIcon           = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $colIcon.HeaderText = "Icon Path"
    $colIcon.Name       = "IconPath"
    $colIcon.Width      = 170
    $dgv.Columns.Add($colIcon) | Out-Null

    # Handle ComboBox DataError (mismatches)
    $dgv.Add_DataError({
        param($s, $e)
        $e.ThrowException = $false
    })

    # Load CSV data into grid
    if (Test-Path $csvPath) {
        $csvData = Import-Csv -Path $csvPath -ErrorAction SilentlyContinue
        if ($csvData) {
            foreach ($row in $csvData) {
                $typeVal = $row.Type
                # Normalize type for ComboBox match (case-insensitive)
                $validTypes = @("CMD", "PowerShell", "PS-NewWindow", "CMD-Close", "OpenSubMenu", "ShowMainMenu")
                $matched = $validTypes | Where-Object { $_ -ieq $typeVal } | Select-Object -First 1
                if (-not $matched) { $matched = $typeVal }  # keep original if no match
                $dgv.Rows.Add($row.ButtonText, $row.Action, $matched, $row.IconPath) | Out-Null
            }
        }
    }

    $editorForm.Controls.Add($dgv)

    # ---- Toolbar buttons ----
    $btnY = 514
    $btnH = 32

    $addBtn = New-ThemedButton -Text "+ Add" -X 14 -Y $btnY -W 90 -H $btnH -Accent -Tooltip "Add a new button row"
    $addBtn.Add_Click({
        $dgv.Rows.Add("New Button", "", "CMD", "") | Out-Null
        $dgv.ClearSelection()
        $dgv.Rows[$dgv.Rows.Count - 1].Selected = $true
        $dgv.FirstDisplayedScrollingRowIndex = $dgv.Rows.Count - 1
    })
    $editorForm.Controls.Add($addBtn)

    $removeBtn = New-ThemedButton -Text "- Remove" -X 112 -Y $btnY -W 100 -H $btnH -Danger -Tooltip "Remove selected button"
    $removeBtn.Add_Click({
        if ($dgv.SelectedRows.Count -gt 0) {
            $idx = $dgv.SelectedRows[0].Index
            $name = $dgv.Rows[$idx].Cells["ButtonText"].Value
            $confirm = [System.Windows.Forms.MessageBox]::Show(
                "Remove button '$name'?", "Confirm Remove", "YesNo", "Warning")
            if ($confirm -eq 'Yes') {
                $dgv.Rows.RemoveAt($idx)
            }
        }
    })
    $editorForm.Controls.Add($removeBtn)

    $dupBtn = New-ThemedButton -Text "Duplicate" -X 220 -Y $btnY -W 100 -H $btnH -Tooltip "Duplicate selected row"
    $dupBtn.Add_Click({
        if ($dgv.SelectedRows.Count -gt 0) {
            $src = $dgv.SelectedRows[0]
            $newIdx = $dgv.Rows.Add(
                $src.Cells["ButtonText"].Value,
                $src.Cells["Action"].Value,
                $src.Cells["Type"].Value,
                $src.Cells["IconPath"].Value
            )
            $dgv.ClearSelection()
            $dgv.Rows[$newIdx].Selected = $true
        }
    })
    $editorForm.Controls.Add($dupBtn)

    # Separator between row actions and move actions
    $toolSep           = New-Object System.Windows.Forms.Panel
    $toolSep.Location  = New-Object System.Drawing.Point(332, ($btnY + 4))
    $toolSep.Size      = New-Object System.Drawing.Size(1, ($btnH - 8))
    $toolSep.BackColor = $theme.Border
    $editorForm.Controls.Add($toolSep)

    $upBtn = New-ThemedButton -Text ([char]0x25B2 + " Up") -X 345 -Y $btnY -W 80 -H $btnH -Tooltip "Move selected row up"
    $upBtn.Add_Click({
        if ($dgv.SelectedRows.Count -gt 0) {
            $idx = $dgv.SelectedRows[0].Index
            if ($idx -gt 0) {
                $vals = @()
                foreach ($col in $dgv.Columns) { $vals += $dgv.Rows[$idx].Cells[$col.Name].Value }
                $dgv.Rows.RemoveAt($idx)
                $dgv.Rows.Insert($idx - 1, $vals)
                $dgv.ClearSelection()
                $dgv.Rows[$idx - 1].Selected = $true
            }
        }
    })
    $editorForm.Controls.Add($upBtn)

    $downBtn = New-ThemedButton -Text ([char]0x25BC + " Down") -X 433 -Y $btnY -W 80 -H $btnH -Tooltip "Move selected row down"
    $downBtn.Add_Click({
        if ($dgv.SelectedRows.Count -gt 0) {
            $idx = $dgv.SelectedRows[0].Index
            if ($idx -lt $dgv.Rows.Count - 1) {
                $vals = @()
                foreach ($col in $dgv.Columns) { $vals += $dgv.Rows[$idx].Cells[$col.Name].Value }
                $dgv.Rows.RemoveAt($idx)
                $dgv.Rows.Insert($idx + 1, $vals)
                $dgv.ClearSelection()
                $dgv.Rows[$idx + 1].Selected = $true
            }
        }
    })
    $editorForm.Controls.Add($downBtn)

    # Right side - Save & Cancel
    $saveBtn = New-ThemedButton -Text "Save && Reload" -X 680 -Y $btnY -W 120 -H $btnH -Accent -Tooltip "Save to CSV and reload buttons"
    $saveBtn.Add_Click({
        # End any in-progress cell edit
        $dgv.EndEdit()

        # Collect rows
        $rows = @()
        for ($i = 0; $i -lt $dgv.Rows.Count; $i++) {
            $btnText  = $dgv.Rows[$i].Cells["ButtonText"].Value
            $action   = $dgv.Rows[$i].Cells["Action"].Value
            $type     = $dgv.Rows[$i].Cells["Type"].Value
            $iconPath = $dgv.Rows[$i].Cells["IconPath"].Value

            # Skip completely empty rows
            if ([string]::IsNullOrWhiteSpace($btnText) -and [string]::IsNullOrWhiteSpace($action)) { continue }

            $rows += [PSCustomObject]@{
                ButtonText = if ($btnText) { $btnText } else { "Untitled" }
                Action     = if ($action)  { $action }  else { "" }
                Type       = if ($type)    { $type }    else { "CMD" }
                IconPath   = if ($iconPath) { $iconPath } else { "" }
            }
        }

        try {
            $rows | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
            Rebuild-ButtonPanels
            [System.Windows.Forms.MessageBox]::Show(
                "Saved $($rows.Count) button(s) to buttons.csv`nButton panels have been reloaded.",
                "Saved", "OK", "Information")
        } catch {
            [System.Windows.Forms.MessageBox]::Show(
                "Failed to save: $($_.Exception.Message)",
                "Save Error", "OK", "Error")
        }
    })
    $editorForm.Controls.Add($saveBtn)

    $cancelBtn = New-ThemedButton -Text "Cancel" -X 808 -Y $btnY -W 84 -H $btnH -Tooltip "Close without saving"
    $cancelBtn.Add_Click({ $editorForm.Close() })
    $editorForm.Controls.Add($cancelBtn)

    # Status label
    $edStatusLabel           = New-Object System.Windows.Forms.Label
    $edStatusLabel.Text      = "CSV: $csvPath  |  $($dgv.Rows.Count) button(s)"
    $edStatusLabel.Font      = $theme.FontSmall
    $edStatusLabel.ForeColor = $theme.TextDisabled
    $edStatusLabel.AutoSize  = $true
    $edStatusLabel.Location  = New-Object System.Drawing.Point(14, 554)
    $edStatusLabel.BackColor = [System.Drawing.Color]::Transparent
    $editorForm.Controls.Add($edStatusLabel)

    # Update status on row changes
    $dgv.Add_RowsAdded({ $edStatusLabel.Text = "CSV: $csvPath  |  $($dgv.Rows.Count) button(s)  [modified]" })
    $dgv.Add_RowsRemoved({ $edStatusLabel.Text = "CSV: $csvPath  |  $($dgv.Rows.Count) button(s)  [modified]" })

    # Keyboard shortcut: Ctrl+S to save
    $editorForm.KeyPreview = $true
    $editorForm.Add_KeyDown({
        param($s, $e)
        if ($e.Control -and $e.KeyCode -eq 'S') {
            $e.SuppressKeyPress = $true
            $saveBtn.PerformClick()
        }
        if ($e.KeyCode -eq 'Escape') {
            $e.SuppressKeyPress = $true
            $editorForm.Close()
        }
    })

    $editorForm.ShowDialog($form) | Out-Null
    $editorForm.Dispose()
}

# ==============================================================================
# FUNCTION: Settings Dialog (tabbed with side navigation)
# ==============================================================================
function Show-SettingsDialog {
    # Work on a clone so Cancel discards changes
    $temp = Clone-Hashtable $script:settings

    $sf               = New-Object System.Windows.Forms.Form
    $sf.Text          = "Settings"
    $sf.Size          = New-Object System.Drawing.Size(700, 720)
    $sf.StartPosition = 'CenterParent'
    $sf.BackColor     = $theme.BG
    $sf.ForeColor     = $theme.TextPrimary
    $sf.Font          = $theme.Font
    $sf.FormBorderStyle = 'FixedDialog'
    $sf.MaximizeBox   = $false
    $sf.MinimizeBox   = $false
    $sf.ShowInTaskbar = $false
    $sf.KeyPreview    = $true

    # ---- Title ----
    $sfTitle           = New-Object System.Windows.Forms.Label
    $sfTitle.Text      = "SETTINGS"
    $sfTitle.Font      = $theme.FontHeader
    $sfTitle.ForeColor = $theme.Accent
    $sfTitle.AutoSize  = $true
    $sfTitle.Location  = New-Object System.Drawing.Point(14, 12)
    $sfTitle.BackColor = [System.Drawing.Color]::Transparent
    $sf.Controls.Add($sfTitle)

    $sfSubtitle           = New-Object System.Windows.Forms.Label
    $sfSubtitle.Text      = "Saved to settings.json  |  Changes apply after Save"
    $sfSubtitle.Font      = $theme.FontSmall
    $sfSubtitle.ForeColor = $theme.TextSecondary
    $sfSubtitle.AutoSize  = $true
    $sfSubtitle.Location  = New-Object System.Drawing.Point(14, 36)
    $sfSubtitle.BackColor = [System.Drawing.Color]::Transparent
    $sf.Controls.Add($sfSubtitle)

    $sfSep           = New-Object System.Windows.Forms.Panel
    $sfSep.Location  = New-Object System.Drawing.Point(14, 56)
    $sfSep.Size      = New-Object System.Drawing.Size(660, 1)
    $sfSep.BackColor = $theme.Border
    $sf.Controls.Add($sfSep)

    # ---- Left navigation panel ----
    $navPanel           = New-Object System.Windows.Forms.Panel
    $navPanel.Location  = New-Object System.Drawing.Point(14, 64)
    $navPanel.Size      = New-Object System.Drawing.Size(150, 558)
    $navPanel.BackColor = $theme.BG_Secondary
    $sf.Controls.Add($navPanel)

    # ---- Right content area ----
    $contentArea           = New-Object System.Windows.Forms.Panel
    $contentArea.Location  = New-Object System.Drawing.Point(172, 64)
    $contentArea.Size      = New-Object System.Drawing.Size(502, 558)
    $contentArea.BackColor = $theme.BG_Secondary
    $sf.Controls.Add($contentArea)

    # Store content panels in hashtable
    $contentPanels = @{}
    $navButtons    = @()
    $script:activeNavBtn = $null

    # Helper: Create a nav button
    function Add-NavButton {
        param([string]$Text, [string]$Key, [int]$Index)
        $btn              = New-Object System.Windows.Forms.Button
        $btn.Text         = $Text
        $btn.Location     = New-Object System.Drawing.Point(0, ($Index * 38))
        $btn.Size         = New-Object System.Drawing.Size(150, 36)
        $btn.FlatStyle    = 'Flat'
        $btn.Font         = $theme.FontBold
        $btn.BackColor    = $theme.BG_Secondary
        $btn.ForeColor    = $theme.TextSecondary
        $btn.TextAlign    = 'MiddleLeft'
        $btn.Padding      = New-Object System.Windows.Forms.Padding(12, 0, 0, 0)
        $btn.Cursor       = [System.Windows.Forms.Cursors]::Hand
        $btn.FlatAppearance.BorderSize  = 0
        $btn.FlatAppearance.BorderColor = $theme.BG_Secondary
        $btn.Tag = $Key
        $navPanel.Controls.Add($btn)
        return $btn
    }

    # Helper: Create a content panel
    function New-ContentPanel {
        $p           = New-Object System.Windows.Forms.Panel
        $p.Location  = New-Object System.Drawing.Point(0, 0)
        $p.Size      = New-Object System.Drawing.Size(502, 558)
        $p.BackColor = $theme.BG_Secondary
        $p.Visible   = $false
        $p.AutoScroll = $true
        $contentArea.Controls.Add($p)
        return $p
    }

    # Helper: add a labeled numeric input row
    function Add-NumericRow {
        param($Panel, [string]$Label, [int]$Y, [int]$Value, [int]$Min, [int]$Max, [string]$Suffix = "")
        $lbl           = New-Object System.Windows.Forms.Label
        $lbl.Text      = $Label
        $lbl.Location  = New-Object System.Drawing.Point(16, $Y)
        $lbl.Size      = New-Object System.Drawing.Size(230, 22)
        $lbl.Font      = $theme.Font
        $lbl.ForeColor = $theme.TextPrimary
        $lbl.BackColor = [System.Drawing.Color]::Transparent
        $Panel.Controls.Add($lbl)

        $nud              = New-Object System.Windows.Forms.NumericUpDown
        $nud.Location     = New-Object System.Drawing.Point(260, ($Y - 2))
        $nud.Size         = New-Object System.Drawing.Size(90, 24)
        $nud.Font         = $theme.FontMono
        $nud.BackColor    = $theme.BG_Input
        $nud.ForeColor    = $theme.TextPrimary
        $nud.BorderStyle  = 'FixedSingle'
        $nud.Minimum      = $Min
        $nud.Maximum      = $Max
        $nud.Value        = [Math]::Max($Min, [Math]::Min($Max, $Value))
        $Panel.Controls.Add($nud)

        if ($Suffix) {
            $sfx           = New-Object System.Windows.Forms.Label
            $sfx.Text      = $Suffix
            $sfx.Location  = New-Object System.Drawing.Point(356, $Y)
            $sfx.AutoSize  = $true
            $sfx.Font      = $theme.FontSmall
            $sfx.ForeColor = $theme.TextSecondary
            $sfx.BackColor = [System.Drawing.Color]::Transparent
            $Panel.Controls.Add($sfx)
        }
        return $nud
    }

    # Helper: add a checkbox row
    function Add-CheckboxRow {
        param($Panel, [string]$Label, [int]$Y, [bool]$Checked)
        $cb             = New-Object System.Windows.Forms.CheckBox
        $cb.Text        = $Label
        $cb.Location    = New-Object System.Drawing.Point(16, $Y)
        $cb.AutoSize    = $true
        $cb.Font        = $theme.Font
        $cb.ForeColor   = $theme.TextPrimary
        $cb.BackColor   = [System.Drawing.Color]::Transparent
        $cb.Checked     = $Checked
        $Panel.Controls.Add($cb)
        return $cb
    }

    # Helper: section header
    function Add-SectionHeader {
        param($Panel, [string]$Text, [int]$Y)
        $lbl           = New-Object System.Windows.Forms.Label
        $lbl.Text      = $Text
        $lbl.Location  = New-Object System.Drawing.Point(16, $Y)
        $lbl.AutoSize  = $true
        $lbl.Font      = $theme.FontSection
        $lbl.ForeColor = $theme.TextMuted
        $lbl.BackColor = [System.Drawing.Color]::Transparent
        $Panel.Controls.Add($lbl)

        $sep           = New-Object System.Windows.Forms.Panel
        $sep.Location  = New-Object System.Drawing.Point(16, ($Y + 16))
        $sep.Size      = New-Object System.Drawing.Size(460, 1)
        $sep.BackColor = $theme.Border
        $Panel.Controls.Add($sep)
    }

    # Helper: add a text input row
    function Add-TextRow {
        param($Panel, [string]$Label, [int]$Y, [string]$Value, [int]$TbWidth = 220)
        $lbl           = New-Object System.Windows.Forms.Label
        $lbl.Text      = $Label
        $lbl.Location  = New-Object System.Drawing.Point(16, $Y)
        $lbl.Size      = New-Object System.Drawing.Size(230, 22)
        $lbl.Font      = $theme.Font
        $lbl.ForeColor = $theme.TextPrimary
        $lbl.BackColor = [System.Drawing.Color]::Transparent
        $Panel.Controls.Add($lbl)

        $tb             = New-Object System.Windows.Forms.TextBox
        $tb.Location    = New-Object System.Drawing.Point(260, ($Y - 2))
        $tb.Size        = New-Object System.Drawing.Size($TbWidth, 24)
        $tb.Font        = $theme.FontMono
        $tb.BackColor   = $theme.BG_Input
        $tb.ForeColor   = $theme.TextPrimary
        $tb.BorderStyle = 'FixedSingle'
        $tb.Text        = $Value
        $Panel.Controls.Add($tb)
        return $tb
    }

    # Helper: add a combobox row
    function Add-ComboRow {
        param($Panel, [string]$Label, [int]$Y, [string[]]$Items, [string]$Selected)
        $lbl           = New-Object System.Windows.Forms.Label
        $lbl.Text      = $Label
        $lbl.Location  = New-Object System.Drawing.Point(16, $Y)
        $lbl.Size      = New-Object System.Drawing.Size(230, 22)
        $lbl.Font      = $theme.Font
        $lbl.ForeColor = $theme.TextPrimary
        $lbl.BackColor = [System.Drawing.Color]::Transparent
        $Panel.Controls.Add($lbl)

        $cb               = New-Object System.Windows.Forms.ComboBox
        $cb.Location      = New-Object System.Drawing.Point(260, ($Y - 2))
        $cb.Size          = New-Object System.Drawing.Size(140, 24)
        $cb.Font          = $theme.FontMono
        $cb.BackColor     = $theme.BG_Input
        $cb.ForeColor     = $theme.TextPrimary
        $cb.FlatStyle     = 'Flat'
        $cb.DropDownStyle = 'DropDownList'
        $Items | ForEach-Object { $cb.Items.Add($_) | Out-Null }
        $idx = $cb.Items.IndexOf($Selected)
        if ($idx -ge 0) { $cb.SelectedIndex = $idx } elseif ($cb.Items.Count -gt 0) { $cb.SelectedIndex = 0 }
        $Panel.Controls.Add($cb)
        return $cb
    }

    # ================================================================
    # PAGE 1: SEARCH
    # ================================================================
    $pSearch = New-ContentPanel
    $contentPanels["Search"] = $pSearch

    Add-SectionHeader $pSearch "AUTO-SEARCH" 10
    $cbAutoSearch = Add-CheckboxRow $pSearch "Enable auto-search while typing" 34 $temp.Search.AutoSearchEnabled
    $nudMinChars  = Add-NumericRow $pSearch "Min. characters for auto-search:" 66  $temp.Search.MinAutoSearchChars  1 10 "chars"
    $nudDebounce  = Add-NumericRow $pSearch "Debounce delay:"                 98  $temp.Search.DebounceMs          100 3000 "ms"
    $nudMaxResult = Add-NumericRow $pSearch "Max search results:"             130 $temp.Search.MaxResults           10 500 "items"

    Add-SectionHeader $pSearch "AD SEARCH SCOPE" 170
    $tbSearchBase = Add-TextRow $pSearch "Search Base OU (empty = all):" 196 $temp.Search.SearchBase 220

    $sbHint           = New-Object System.Windows.Forms.Label
    $sbHint.Text      = "Example: OU=Workstations,DC=soroka,DC=local"
    $sbHint.Location  = New-Object System.Drawing.Point(16, 224)
    $sbHint.AutoSize  = $true
    $sbHint.Font      = $theme.FontSmall
    $sbHint.ForeColor = $theme.TextDisabled
    $sbHint.BackColor = [System.Drawing.Color]::Transparent
    $pSearch.Controls.Add($sbHint)

    # ================================================================
    # PAGE 2: PING
    # ================================================================
    $pPing = New-ContentPanel
    $contentPanels["Ping"] = $pPing

    Add-SectionHeader $pPing "PING BEHAVIOR" 10
    $nudPingInterval = Add-NumericRow $pPing "Repeat interval:"    36  $temp.Ping.RepeatIntervalMs  1000 30000 "ms"
    $nudPingTimeout  = Add-NumericRow $pPing "Ping timeout:"       68  $temp.Ping.TimeoutMs         500  10000 "ms"
    $cbAutoRepeat    = Add-CheckboxRow $pPing "Auto-repeat ping after selecting computer" 104 $temp.Ping.AutoRepeat

    Add-SectionHeader $pPing "NOTIFICATIONS" 144
    $cbSoundOnChange = Add-CheckboxRow $pPing "Play sound on status change (online/offline)" 170 $temp.Ping.SoundOnStatusChange

    # ================================================================
    # PAGE 3: APPEARANCE
    # ================================================================
    $pAppearance = New-ContentPanel
    $contentPanels["Appearance"] = $pAppearance

    Add-SectionHeader $pAppearance "THEME" 10
    $cboAccent = Add-ComboRow $pAppearance "Accent color preset:" 36 @("Blue", "Green", "Purple", "Orange", "Red", "Teal") $temp.Appearance.AccentPreset

    # Color preview swatch
    $accentPreview           = New-Object System.Windows.Forms.Panel
    $accentPreview.Location  = New-Object System.Drawing.Point(410, 34)
    $accentPreview.Size      = New-Object System.Drawing.Size(24, 24)
    $accentPreview.BackColor = $theme.Accent
    $pAppearance.Controls.Add($accentPreview)

    $accentColors = @{
        "Blue"   = [System.Drawing.Color]::FromArgb(78, 120, 255)
        "Green"  = [System.Drawing.Color]::FromArgb(72, 200, 110)
        "Purple" = [System.Drawing.Color]::FromArgb(155, 89, 255)
        "Orange" = [System.Drawing.Color]::FromArgb(255, 150, 50)
        "Red"    = [System.Drawing.Color]::FromArgb(255, 85, 85)
        "Teal"   = [System.Drawing.Color]::FromArgb(50, 200, 180)
    }
    $cboAccent.Add_SelectedIndexChanged({
        $sel = $cboAccent.SelectedItem.ToString()
        if ($accentColors.ContainsKey($sel)) {
            $accentPreview.BackColor = $accentColors[$sel]
        }
    }.GetNewClosure())

    Add-SectionHeader $pAppearance "FONT" 78
    $nudFontSize = Add-NumericRow $pAppearance "Font size:" 104 $temp.Appearance.FontSize 7 14 "pt"

    Add-SectionHeader $pAppearance "WINDOW" 144
    $cbAlwaysOnTop  = Add-CheckboxRow $pAppearance "Always on top"                   170 $temp.Appearance.AlwaysOnTop
    $cbLockPosition = Add-CheckboxRow $pAppearance "Lock window position on screen"  198 $temp.Appearance.LockPosition

    $accentNote           = New-Object System.Windows.Forms.Label
    $accentNote.Text      = "* Color and font changes require restarting the tool."
    $accentNote.Location  = New-Object System.Drawing.Point(16, 240)
    $accentNote.AutoSize  = $true
    $accentNote.Font      = $theme.FontSmall
    $accentNote.ForeColor = $theme.Warning
    $accentNote.BackColor = [System.Drawing.Color]::Transparent
    $pAppearance.Controls.Add($accentNote)

    # ================================================================
    # PAGE 4: RDP
    # ================================================================
    $pRDP = New-ContentPanel
    $contentPanels["RDP"] = $pRDP

    Add-SectionHeader $pRDP "REMOTE DESKTOP" 10
    $cbRDPFullscreen = Add-CheckboxRow $pRDP "Fullscreen mode"                     36  $temp.RDP.Fullscreen
    $cbRDPAdmin      = Add-CheckboxRow $pRDP "Connect to admin/console session (/admin)"  64  $temp.RDP.AdminSession
    $cbRDPMultiMon   = Add-CheckboxRow $pRDP "Multi-monitor (/multimon)"           92  $temp.RDP.MultiMon

    Add-SectionHeader $pRDP "CUSTOM RESOLUTION (if not fullscreen)" 130
    $nudRDPWidth  = Add-NumericRow $pRDP "Width:"  156 $temp.RDP.CustomWidth  0 3840 "px  (0 = default)"
    $nudRDPHeight = Add-NumericRow $pRDP "Height:" 188 $temp.RDP.CustomHeight 0 2160 "px  (0 = default)"

    # ================================================================
    # PAGE 5: RESTART
    # ================================================================
    $pRestart = New-ContentPanel
    $contentPanels["Restart"] = $pRestart

    Add-SectionHeader $pRestart "REMOTE RESTART" 10
    $nudRestartDelay = Add-NumericRow $pRestart "Delay before restart:" 36 $temp.Restart.DelaySeconds 0 600 "seconds (0 = immediate)"
    $cbShowMessage   = Add-CheckboxRow $pRestart "Show message to user before restart" 68 $temp.Restart.ShowMessage

    Add-SectionHeader $pRestart "DEFAULT MESSAGE" 104
    $tbRestartMsg             = New-Object System.Windows.Forms.TextBox
    $tbRestartMsg.Location    = New-Object System.Drawing.Point(16, 130)
    $tbRestartMsg.Size        = New-Object System.Drawing.Size(460, 60)
    $tbRestartMsg.Font        = $theme.FontMono
    $tbRestartMsg.BackColor   = $theme.BG_Input
    $tbRestartMsg.ForeColor   = $theme.TextPrimary
    $tbRestartMsg.BorderStyle = 'FixedSingle'
    $tbRestartMsg.Multiline   = $true
    $tbRestartMsg.Text        = $temp.Restart.DefaultMessage
    $pRestart.Controls.Add($tbRestartMsg)

    $msgHint           = New-Object System.Windows.Forms.Label
    $msgHint.Text      = "This message appears on the remote user's screen before restart."
    $msgHint.Location  = New-Object System.Drawing.Point(16, 196)
    $msgHint.AutoSize  = $true
    $msgHint.Font      = $theme.FontSmall
    $msgHint.ForeColor = $theme.TextDisabled
    $msgHint.BackColor = [System.Drawing.Color]::Transparent
    $pRestart.Controls.Add($msgHint)

    # ================================================================
    # PAGE 6: LOGON
    # ================================================================
    $pLogon = New-ContentPanel
    $contentPanels["Logon"] = $pLogon

    Add-SectionHeader $pLogon "LOGGED ON USERS" 10
    $cbLogonAutoRefresh    = Add-CheckboxRow $pLogon "Auto-refresh logged on users" 36 $temp.Logon.AutoRefresh
    $nudLogonRefreshSec    = Add-NumericRow $pLogon "Refresh interval:" 68 $temp.Logon.RefreshIntervalSec 10 300 "seconds"

    # ================================================================
    # PAGE 7: LAYOUT
    # ================================================================
    $pLayout = New-ContentPanel
    $contentPanels["Layout"] = $pLayout

    Add-SectionHeader $pLayout "ACTION BUTTONS" 10
    $nudBtnWidth   = Add-NumericRow $pLayout "Button width:"   36  $temp.Layout.ButtonWidth   100 400 "px"
    $nudBtnHeight  = Add-NumericRow $pLayout "Button height:"  68  $temp.Layout.ButtonHeight  28  80  "px"
    $nudBtnColumns = Add-NumericRow $pLayout "Columns:"        100 $temp.Layout.ButtonColumns 1   3   "columns"

    $layoutNote           = New-Object System.Windows.Forms.Label
    $layoutNote.Text      = "* Layout changes require pressing Save && Reload in the`n  Button Editor, or restarting the tool."
    $layoutNote.Location  = New-Object System.Drawing.Point(16, 140)
    $layoutNote.Size      = New-Object System.Drawing.Size(460, 36)
    $layoutNote.Font      = $theme.FontSmall
    $layoutNote.ForeColor = $theme.Warning
    $layoutNote.BackColor = [System.Drawing.Color]::Transparent
    $pLayout.Controls.Add($layoutNote)

    # ================================================================
    # PAGE 8: BEHAVIOR
    # ================================================================
    $pBehavior = New-ContentPanel
    $contentPanels["Behavior"] = $pBehavior

    Add-SectionHeader $pBehavior "STARTUP" 10
    $cbRememberComputer = Add-CheckboxRow $pBehavior "Remember last selected computer on startup" 36 $temp.Behavior.RememberLastComputer

    $lastPcLabel           = New-Object System.Windows.Forms.Label
    $lastPcLabel.Text      = if ($temp.Behavior.LastComputer) { "Last: $($temp.Behavior.LastComputer)" } else { "No computer saved yet" }
    $lastPcLabel.Location  = New-Object System.Drawing.Point(16, 66)
    $lastPcLabel.AutoSize  = $true
    $lastPcLabel.Font      = $theme.FontSmall
    $lastPcLabel.ForeColor = $theme.TextDisabled
    $lastPcLabel.BackColor = [System.Drawing.Color]::Transparent
    $pBehavior.Controls.Add($lastPcLabel)

    # ================================================================
    # PAGE 9: SHORTCUTS
    # ================================================================
    $pShortcuts = New-ContentPanel
    $contentPanels["Shortcuts"] = $pShortcuts

    Add-SectionHeader $pShortcuts "KEYBOARD SHORTCUTS" 10

    $shortcutHint           = New-Object System.Windows.Forms.Label
    $shortcutHint.Text      = "Format: Ctrl+KEY  (e.g. Ctrl+F, Ctrl+Shift+P)"
    $shortcutHint.Location  = New-Object System.Drawing.Point(16, 30)
    $shortcutHint.AutoSize  = $true
    $shortcutHint.Font      = $theme.FontSmall
    $shortcutHint.ForeColor = $theme.TextDisabled
    $shortcutHint.BackColor = [System.Drawing.Color]::Transparent
    $pShortcuts.Controls.Add($shortcutHint)

    $tbShortSearch  = Add-TextRow $pShortcuts "Focus Search:"      54  $temp.Shortcuts.Search  100
    $tbShortPing    = Add-TextRow $pShortcuts "Continuous Ping:"    86  $temp.Shortcuts.Ping    100
    $tbShortRDP     = Add-TextRow $pShortcuts "Remote Desktop:"    118 $temp.Shortcuts.RDP     100
    $tbShortCShare  = Add-TextRow $pShortcuts "Open C`$:"           150 $temp.Shortcuts.CShare  100

    $shortcutNote           = New-Object System.Windows.Forms.Label
    $shortcutNote.Text      = "* Shortcut changes require restarting the tool."
    $shortcutNote.Location  = New-Object System.Drawing.Point(16, 188)
    $shortcutNote.AutoSize  = $true
    $shortcutNote.Font      = $theme.FontSmall
    $shortcutNote.ForeColor = $theme.Warning
    $shortcutNote.BackColor = [System.Drawing.Color]::Transparent
    $pShortcuts.Controls.Add($shortcutNote)

    # ================================================================
    # PAGE 10: PATHS
    # ================================================================
    $pPaths = New-ContentPanel
    $contentPanels["Paths"] = $pPaths

    Add-SectionHeader $pPaths "EXTERNAL TOOLS" 10

    # DameWare
    $lblDW           = New-Object System.Windows.Forms.Label
    $lblDW.Text      = "DameWare path:"
    $lblDW.Location  = New-Object System.Drawing.Point(16, 34)
    $lblDW.AutoSize  = $true
    $lblDW.Font      = $theme.Font
    $lblDW.ForeColor = $theme.TextPrimary
    $lblDW.BackColor = [System.Drawing.Color]::Transparent
    $pPaths.Controls.Add($lblDW)

    $tbDameWare             = New-Object System.Windows.Forms.TextBox
    $tbDameWare.Location    = New-Object System.Drawing.Point(16, 54)
    $tbDameWare.Size        = New-Object System.Drawing.Size(420, 24)
    $tbDameWare.Font        = $theme.FontMono
    $tbDameWare.BackColor   = $theme.BG_Input
    $tbDameWare.ForeColor   = $theme.TextPrimary
    $tbDameWare.BorderStyle = 'FixedSingle'
    $tbDameWare.Text        = $temp.Paths.DameWarePath
    $pPaths.Controls.Add($tbDameWare)

    $btnBrowseDW              = New-Object System.Windows.Forms.Button
    $btnBrowseDW.Text         = "..."
    $btnBrowseDW.Location     = New-Object System.Drawing.Point(440, 53)
    $btnBrowseDW.Size         = New-Object System.Drawing.Size(36, 26)
    $btnBrowseDW.FlatStyle    = 'Flat'
    $btnBrowseDW.Font         = $theme.FontBold
    $btnBrowseDW.BackColor    = $theme.ButtonBG
    $btnBrowseDW.ForeColor    = $theme.TextPrimary
    $btnBrowseDW.Cursor       = [System.Windows.Forms.Cursors]::Hand
    $btnBrowseDW.FlatAppearance.BorderColor = $theme.ButtonBorder
    $btnBrowseDW.FlatAppearance.BorderSize  = 1
    $btnBrowseDW.Add_Click({
        $ofd = New-Object System.Windows.Forms.OpenFileDialog
        $ofd.Filter = "Executable (*.exe)|*.exe|All Files (*.*)|*.*"
        $ofd.Title  = "Select DameWare executable"
        if ($ofd.ShowDialog() -eq 'OK') { $tbDameWare.Text = $ofd.FileName }
        $ofd.Dispose()
    })
    $pPaths.Controls.Add($btnBrowseDW)

    # PsExec
    $lblPsExec           = New-Object System.Windows.Forms.Label
    $lblPsExec.Text      = "PsExec path:"
    $lblPsExec.Location  = New-Object System.Drawing.Point(16, 90)
    $lblPsExec.AutoSize  = $true
    $lblPsExec.Font      = $theme.Font
    $lblPsExec.ForeColor = $theme.TextPrimary
    $lblPsExec.BackColor = [System.Drawing.Color]::Transparent
    $pPaths.Controls.Add($lblPsExec)

    $tbPsExec             = New-Object System.Windows.Forms.TextBox
    $tbPsExec.Location    = New-Object System.Drawing.Point(16, 110)
    $tbPsExec.Size        = New-Object System.Drawing.Size(420, 24)
    $tbPsExec.Font        = $theme.FontMono
    $tbPsExec.BackColor   = $theme.BG_Input
    $tbPsExec.ForeColor   = $theme.TextPrimary
    $tbPsExec.BorderStyle = 'FixedSingle'
    $tbPsExec.Text        = $temp.Paths.PsExecPath
    $pPaths.Controls.Add($tbPsExec)

    $btnBrowsePsExec              = New-Object System.Windows.Forms.Button
    $btnBrowsePsExec.Text         = "..."
    $btnBrowsePsExec.Location     = New-Object System.Drawing.Point(440, 109)
    $btnBrowsePsExec.Size         = New-Object System.Drawing.Size(36, 26)
    $btnBrowsePsExec.FlatStyle    = 'Flat'
    $btnBrowsePsExec.Font         = $theme.FontBold
    $btnBrowsePsExec.BackColor    = $theme.ButtonBG
    $btnBrowsePsExec.ForeColor    = $theme.TextPrimary
    $btnBrowsePsExec.Cursor       = [System.Windows.Forms.Cursors]::Hand
    $btnBrowsePsExec.FlatAppearance.BorderColor = $theme.ButtonBorder
    $btnBrowsePsExec.FlatAppearance.BorderSize  = 1
    $btnBrowsePsExec.Add_Click({
        $ofd = New-Object System.Windows.Forms.OpenFileDialog
        $ofd.Filter = "Executable (*.exe)|*.exe|All Files (*.*)|*.*"
        $ofd.Title  = "Select PsExec executable"
        if ($ofd.ShowDialog() -eq 'OK') { $tbPsExec.Text = $ofd.FileName }
        $ofd.Dispose()
    })
    $pPaths.Controls.Add($btnBrowsePsExec)

    Add-SectionHeader $pPaths "ICONS" 150
    $tbIconsFolder = Add-TextRow $pPaths "Icons folder name:" 176 $temp.Paths.IconsFolder 220

    # ================================================================
    # PAGE 11: HISTORY
    # ================================================================
    $pHistory = New-ContentPanel
    $contentPanels["History"] = $pHistory

    Add-SectionHeader $pHistory "LIMITS" 10
    $nudMaxHistory     = Add-NumericRow $pHistory "Max history items:"               36  $temp.History.MaxItems       10 500 "items (0 = unlimited)"
    $nudAutoClearDays  = Add-NumericRow $pHistory "Auto-clear items older than:"     68  $temp.History.AutoClearDays  0  365 "days (0 = never)"

    # ================================================================
    # PAGE 12: CONFIG (Export / Import / Reset)
    # ================================================================
    $pConfig = New-ContentPanel
    $contentPanels["Config"] = $pConfig

    Add-SectionHeader $pConfig "CONFIGURATION MANAGEMENT" 10

    $cfgInfoLabel           = New-Object System.Windows.Forms.Label
    $cfgInfoLabel.Text      = "Export or import your settings.json file to share`nconfiguration with other team members."
    $cfgInfoLabel.Location  = New-Object System.Drawing.Point(16, 36)
    $cfgInfoLabel.Size      = New-Object System.Drawing.Size(460, 40)
    $cfgInfoLabel.Font      = $theme.Font
    $cfgInfoLabel.ForeColor = $theme.TextSecondary
    $cfgInfoLabel.BackColor = [System.Drawing.Color]::Transparent
    $pConfig.Controls.Add($cfgInfoLabel)

    $btnExport = New-ThemedButton -Text "Export Settings..." -X 16 -Y 86 -W 145 -H 32 -Accent
    $btnExport.Add_Click({
        $sfd = New-Object System.Windows.Forms.SaveFileDialog
        $sfd.Filter   = "JSON files (*.json)|*.json"
        $sfd.FileName = "settings.json"
        $sfd.Title    = "Export Settings"
        if ($sfd.ShowDialog() -eq 'OK') {
            try {
                Copy-Item $settingsFilePath $sfd.FileName -Force
                [System.Windows.Forms.MessageBox]::Show("Settings exported to:`n$($sfd.FileName)", "Export", "OK", "Information")
            } catch {
                [System.Windows.Forms.MessageBox]::Show("Export failed: $($_.Exception.Message)", "Error", "OK", "Error")
            }
        }
        $sfd.Dispose()
    })
    $pConfig.Controls.Add($btnExport)

    $btnImport = New-ThemedButton -Text "Import Settings..." -X 170 -Y 86 -W 145 -H 32
    $btnImport.Add_Click({
        $ofd = New-Object System.Windows.Forms.OpenFileDialog
        $ofd.Filter = "JSON files (*.json)|*.json"
        $ofd.Title  = "Import Settings"
        if ($ofd.ShowDialog() -eq 'OK') {
            try {
                Copy-Item $ofd.FileName $settingsFilePath -Force
                Load-Settings
                [System.Windows.Forms.MessageBox]::Show(
                    "Settings imported. Restart the tool for all changes to take effect.",
                    "Import", "OK", "Information")
                $sf.Close()
            } catch {
                [System.Windows.Forms.MessageBox]::Show("Import failed: $($_.Exception.Message)", "Error", "OK", "Error")
            }
        }
        $ofd.Dispose()
    })
    $pConfig.Controls.Add($btnImport)

    Add-SectionHeader $pConfig "RESET" 140

    $btnReset = New-ThemedButton -Text "Reset to Defaults" -X 16 -Y 168 -W 145 -H 32 -Danger
    $btnReset.Add_Click({
        $confirm = [System.Windows.Forms.MessageBox]::Show(
            "Reset all settings to factory defaults?`nThis cannot be undone.",
            "Confirm Reset", "YesNo", "Warning")
        if ($confirm -eq 'Yes') {
            $script:settings = Clone-Hashtable $script:settingsDefaults
            Save-Settings
            [System.Windows.Forms.MessageBox]::Show(
                "Settings reset. Restart the tool for all changes to take effect.",
                "Reset", "OK", "Information")
            $sf.Close()
        }
    })
    $pConfig.Controls.Add($btnReset)

    $cfgPathLabel           = New-Object System.Windows.Forms.Label
    $cfgPathLabel.Text      = "File: $settingsFilePath"
    $cfgPathLabel.Location  = New-Object System.Drawing.Point(16, 220)
    $cfgPathLabel.AutoSize  = $true
    $cfgPathLabel.Font      = $theme.FontSmall
    $cfgPathLabel.ForeColor = $theme.TextDisabled
    $cfgPathLabel.BackColor = [System.Drawing.Color]::Transparent
    $pConfig.Controls.Add($cfgPathLabel)

    # ================================================================
    # NAVIGATION BUTTONS
    # ================================================================
    $navDefs = @(
        @{ Text = "$([char]0x25B8)  Search";       Key = "Search" }
        @{ Text = "$([char]0x25C9)  Ping";         Key = "Ping" }
        @{ Text = "$([char]0x2699)  Appearance";   Key = "Appearance" }
        @{ Text = "$([char]0x25A3)  RDP";          Key = "RDP" }
        @{ Text = "$([char]0x21BB)  Restart";      Key = "Restart" }
        @{ Text = "$([char]0x25CB)  Logon";        Key = "Logon" }
        @{ Text = "$([char]0x25A6)  Layout";       Key = "Layout" }
        @{ Text = "$([char]0x25CF)  Behavior";     Key = "Behavior" }
        @{ Text = "$([char]0x2328)  Shortcuts";    Key = "Shortcuts" }
        @{ Text = "$([char]0x2302)  Paths";        Key = "Paths" }
        @{ Text = "$([char]0x2630)  History";      Key = "History" }
        @{ Text = "$([char]0x2193)  Config";       Key = "Config" }
    )

    $navIdx = 0
    foreach ($def in $navDefs) {
        $nb = Add-NavButton -Text $def.Text -Key $def.Key -Index $navIdx
        $navButtons += $nb
        $panelKey = $def.Key
        $nb.Add_Click({
            $key = $this.Tag
            # Hide all panels
            foreach ($p in $contentPanels.Values) { $p.Visible = $false }
            # Deselect all nav buttons (use navPanel.Controls - live reference, not captured array)
            foreach ($ctrl in $navPanel.Controls) {
                if ($ctrl -is [System.Windows.Forms.Button] -and $ctrl.Tag -is [string]) {
                    $ctrl.BackColor = $theme.BG_Secondary
                    $ctrl.ForeColor = $theme.TextSecondary
                }
            }
            # Show selected
            if ($contentPanels.ContainsKey($key)) { $contentPanels[$key].Visible = $true }
            $this.BackColor = $theme.AccentSubtle
            $this.ForeColor = $theme.TextPrimary
        }.GetNewClosure())
        $navIdx++
    }

    # Separator between nav and "Edit Buttons"
    $navSep2           = New-Object System.Windows.Forms.Panel
    $navSep2.Location  = New-Object System.Drawing.Point(8, ($navIdx * 38 + 6))
    $navSep2.Size      = New-Object System.Drawing.Size(134, 1)
    $navSep2.BackColor = $theme.Border
    $navPanel.Controls.Add($navSep2)

    # Extra nav: Edit Buttons (launches existing editor)
    $btnEditButtons              = New-Object System.Windows.Forms.Button
    $btnEditButtons.Text         = "$([char]0x270E)  Edit Buttons..."
    $btnEditButtons.Location     = New-Object System.Drawing.Point(0, ($navIdx * 38 + 14))
    $btnEditButtons.Size         = New-Object System.Drawing.Size(150, 40)
    $btnEditButtons.FlatStyle    = 'Flat'
    $btnEditButtons.Font         = $theme.FontBold
    $btnEditButtons.BackColor    = $theme.BG_Secondary
    $btnEditButtons.ForeColor    = $theme.Accent
    $btnEditButtons.TextAlign    = 'MiddleLeft'
    $btnEditButtons.Padding      = New-Object System.Windows.Forms.Padding(12, 0, 0, 0)
    $btnEditButtons.Cursor       = [System.Windows.Forms.Cursors]::Hand
    $btnEditButtons.FlatAppearance.BorderSize  = 0
    $btnEditButtons.FlatAppearance.BorderColor = $theme.BG_Secondary
    $btnEditButtons.Add_Click({ Show-ButtonEditor })
    $navPanel.Controls.Add($btnEditButtons)

    # ---- Bottom buttons (Save / Cancel) ----
    $btnSave = New-ThemedButton -Text "Save && Apply" -X 476 -Y 636 -W 115 -H 34 -Accent
    $btnSave.Add_Click({
        # Collect all values from controls back into $temp
        $temp.Search.MinAutoSearchChars  = [int]$nudMinChars.Value
        $temp.Search.DebounceMs          = [int]$nudDebounce.Value
        $temp.Search.MaxResults          = [int]$nudMaxResult.Value
        $temp.Search.SearchBase          = $tbSearchBase.Text.Trim()
        $temp.Search.AutoSearchEnabled   = $cbAutoSearch.Checked

        $temp.Ping.RepeatIntervalMs      = [int]$nudPingInterval.Value
        $temp.Ping.TimeoutMs             = [int]$nudPingTimeout.Value
        $temp.Ping.AutoRepeat            = $cbAutoRepeat.Checked
        $temp.Ping.SoundOnStatusChange   = $cbSoundOnChange.Checked

        $temp.Appearance.AccentPreset    = $cboAccent.SelectedItem.ToString()
        $temp.Appearance.FontSize        = [int]$nudFontSize.Value
        $temp.Appearance.AlwaysOnTop     = $cbAlwaysOnTop.Checked
        $temp.Appearance.LockPosition    = $cbLockPosition.Checked

        $temp.RDP.Fullscreen             = $cbRDPFullscreen.Checked
        $temp.RDP.AdminSession           = $cbRDPAdmin.Checked
        $temp.RDP.MultiMon               = $cbRDPMultiMon.Checked
        $temp.RDP.CustomWidth            = [int]$nudRDPWidth.Value
        $temp.RDP.CustomHeight           = [int]$nudRDPHeight.Value

        $temp.Restart.DelaySeconds       = [int]$nudRestartDelay.Value
        $temp.Restart.ShowMessage        = $cbShowMessage.Checked
        $temp.Restart.DefaultMessage     = $tbRestartMsg.Text

        $temp.Logon.AutoRefresh          = $cbLogonAutoRefresh.Checked
        $temp.Logon.RefreshIntervalSec   = [int]$nudLogonRefreshSec.Value

        $temp.Layout.ButtonWidth         = [int]$nudBtnWidth.Value
        $temp.Layout.ButtonHeight        = [int]$nudBtnHeight.Value
        $temp.Layout.ButtonColumns       = [int]$nudBtnColumns.Value

        $temp.Behavior.RememberLastComputer = $cbRememberComputer.Checked

        $temp.Shortcuts.Search           = $tbShortSearch.Text.Trim()
        $temp.Shortcuts.Ping             = $tbShortPing.Text.Trim()
        $temp.Shortcuts.RDP              = $tbShortRDP.Text.Trim()
        $temp.Shortcuts.CShare           = $tbShortCShare.Text.Trim()

        $temp.Paths.DameWarePath         = $tbDameWare.Text.Trim()
        $temp.Paths.PsExecPath           = $tbPsExec.Text.Trim()
        $temp.Paths.IconsFolder          = $tbIconsFolder.Text.Trim()

        $temp.History.MaxItems           = [int]$nudMaxHistory.Value
        $temp.History.AutoClearDays      = [int]$nudAutoClearDays.Value

        # Apply to live settings
        $script:settings = $temp
        Save-Settings
        Apply-LiveSettings
        $sf.DialogResult = [System.Windows.Forms.DialogResult]::OK
        $sf.Close()
    })
    $sf.Controls.Add($btnSave)

    $btnCancel = New-ThemedButton -Text "Cancel" -X 597 -Y 636 -W 80 -H 34
    $btnCancel.Add_Click({ $sf.Close() })
    $sf.Controls.Add($btnCancel)

    # Keyboard shortcuts
    $sf.Add_KeyDown({
        param($s, $e)
        if ($e.Control -and $e.KeyCode -eq 'S') {
            $e.SuppressKeyPress = $true
            $btnSave.PerformClick()
        }
        if ($e.KeyCode -eq 'Escape') {
            $e.SuppressKeyPress = $true
            $sf.Close()
        }
    })

    # Select first page
    if ($navButtons.Count -gt 0) { $navButtons[0].PerformClick() }

    $sf.ShowDialog($form) | Out-Null
    $sf.Dispose()
}

# ==============================================================================
# FUNCTION: Apply live settings (called after Save without restarting)
# ==============================================================================
function Apply-LiveSettings {
    # Search
    $script:minAutoSearchChars       = $script:settings.Search.MinAutoSearchChars
    $script:searchTimer.Interval     = $script:settings.Search.DebounceMs

    # Ping
    $script:pingRepeatTimer.Interval = $script:settings.Ping.RepeatIntervalMs

    # Window
    $form.TopMost        = $script:settings.Appearance.AlwaysOnTop
    $script:formLocked   = $script:settings.Appearance.LockPosition
    if (-not $script:formLocked) { $script:formPosition = $null }

    # Logon auto-refresh
    $script:logonAutoRefreshTimer.Stop()
    if ($script:settings.Logon.AutoRefresh -and $script:selectedComputer) {
        $script:logonAutoRefreshTimer.Interval = [Math]::Max(10000, $script:settings.Logon.RefreshIntervalSec * 1000)
        $script:logonAutoRefreshTimer.Start()
    }

    # Rebuild buttons if layout changed
    Rebuild-ButtonPanels

    # Update default status bar with current shortcuts
    $sc = $script:settings.Shortcuts
    $script:defaultStatus = "Ready  |  $($sc.Search): Search  |  $($sc.Ping): Ping  |  $($sc.RDP): RDP  |  $($sc.CShare): C$"

    # Trim history to max
    $maxH = $script:settings.History.MaxItems
    if ($maxH -gt 0) {
        while ($historyListBox.Items.Count -gt $maxH) {
            $historyListBox.Items.RemoveAt($historyListBox.Items.Count - 1)
        }
        Save-History
    }

    Set-Status "Settings applied" "Success"
}

# ==============================================================================
# FORM
# ==============================================================================
$form               = New-Object System.Windows.Forms.Form
$form.Text          = 'Remote Admin Tool v3.0'
$form.Size          = New-Object System.Drawing.Size(1470, 790)
$form.BackColor     = $theme.BG
$form.ForeColor     = $theme.TextPrimary
$form.Font          = $theme.Font
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox   = $false
$form.KeyPreview    = $true
$form.TopMost       = $script:settings.Appearance.AlwaysOnTop

# Restore window position or center on screen
$savedX = $script:settings.Behavior.LastWindowX
$savedY = $script:settings.Behavior.LastWindowY
if ($savedX -ge 0 -and $savedY -ge 0) {
    # Validate the saved position is on a visible screen
    $testPoint = New-Object System.Drawing.Point($savedX, $savedY)
    $onScreen  = $false
    foreach ($scr in [System.Windows.Forms.Screen]::AllScreens) {
        if ($scr.WorkingArea.Contains($testPoint)) { $onScreen = $true; break }
    }
    if ($onScreen) {
        $form.StartPosition = 'Manual'
        $form.Location      = New-Object System.Drawing.Point($savedX, $savedY)
    } else {
        $form.StartPosition = 'CenterScreen'
    }
} else {
    $form.StartPosition = 'CenterScreen'
}

# Lock form position - snap back if moved
$script:formLocked   = $script:settings.Appearance.LockPosition
$script:formPosition = $null
$form.Add_Shown({
    $script:formPosition = $form.Location
    $form.WindowState = 'Normal'
    $form.Activate()
    $computerInputBox.Focus()
}.GetNewClosure())
$form.Add_LocationChanged({
    if ($script:formLocked -and $script:formPosition) {
        $form.Location = $script:formPosition
    }
})

# ==============================================================================
# HEADER BAR
# ==============================================================================
$headerPanel           = New-Object System.Windows.Forms.Panel
$headerPanel.Dock      = 'Top'
$headerPanel.Height    = 42
$headerPanel.BackColor = $theme.BG_Secondary

$headerLabel           = New-Object System.Windows.Forms.Label
$headerLabel.Text      = "REMOTE ADMIN TOOL"
$headerLabel.Font      = $theme.FontHeader
$headerLabel.ForeColor = $theme.Accent
$headerLabel.AutoSize  = $true
$headerLabel.Location  = New-Object System.Drawing.Point(14, 10)
$headerLabel.BackColor = [System.Drawing.Color]::Transparent
$headerPanel.Controls.Add($headerLabel)

$headerVersion           = New-Object System.Windows.Forms.Label
$headerVersion.Text      = "v3.0"
$headerVersion.Font      = $theme.FontSmall
$headerVersion.ForeColor = $theme.TextDisabled
$headerVersion.AutoSize  = $true
$headerVersion.Location  = New-Object System.Drawing.Point(195, 14)
$headerVersion.BackColor = [System.Drawing.Color]::Transparent
$headerPanel.Controls.Add($headerVersion)

$headerSep           = New-Object System.Windows.Forms.Panel
$headerSep.Dock      = 'Bottom'
$headerSep.Height    = 1
$headerSep.BackColor = $theme.Border
$headerPanel.Controls.Add($headerSep)

# Settings (gear) button in header - right-aligned
$settingsBtn               = New-Object System.Windows.Forms.Button
$settingsBtn.Text          = [char]0x2699 + "  Settings"
$settingsBtn.Size          = New-Object System.Drawing.Size(105, 30)
$settingsBtn.Location      = New-Object System.Drawing.Point(1338, 6)
$settingsBtn.FlatStyle     = 'Flat'
$settingsBtn.Font          = $theme.Font
$settingsBtn.BackColor     = $theme.ButtonBG
$settingsBtn.ForeColor     = $theme.TextPrimary
$settingsBtn.Cursor        = [System.Windows.Forms.Cursors]::Hand
$settingsBtn.FlatAppearance.BorderColor = $theme.ButtonBorder
$settingsBtn.FlatAppearance.BorderSize  = 1
$colorNormal_s = $theme.ButtonBG
$colorHover_s  = $theme.ButtonBGHover
$settingsBtn.Add_MouseEnter({ $this.BackColor = $colorHover_s  }.GetNewClosure())
$settingsBtn.Add_MouseLeave({ $this.BackColor = $colorNormal_s }.GetNewClosure())
$settingsBtn.Add_Click({ Show-SettingsDialog })
$script:toolTip.SetToolTip($settingsBtn, "Application settings & configuration")
$headerPanel.Controls.Add($settingsBtn)

$form.Controls.Add($headerPanel)

# ==============================================================================
# STATUS BAR
# ==============================================================================
$statusStrip            = New-Object System.Windows.Forms.StatusStrip
$statusStrip.BackColor  = $theme.StatusBG
$statusStrip.SizingGrip = $false

$script:statusLabel           = New-Object System.Windows.Forms.ToolStripStatusLabel
$script:statusLabel.Text      = "  [i] Ready"
$script:statusLabel.ForeColor = $theme.TextSecondary
$script:statusLabel.Font      = $theme.Font
$script:statusLabel.Spring    = $true
$script:statusLabel.TextAlign = 'MiddleLeft'
$statusStrip.Items.Add($script:statusLabel) | Out-Null

$script:statusComputer           = New-Object System.Windows.Forms.ToolStripStatusLabel
$script:statusComputer.Text      = "No computer selected  "
$script:statusComputer.ForeColor = $theme.TextDisabled
$script:statusComputer.Font      = $theme.FontBold
$statusStrip.Items.Add($script:statusComputer) | Out-Null

# Separator before credit
$statusSep           = New-Object System.Windows.Forms.ToolStripSeparator
$statusSep.ForeColor = $theme.Border
$statusStrip.Items.Add($statusSep) | Out-Null

# Credit label
$creditLabel           = New-Object System.Windows.Forms.ToolStripStatusLabel
$creditLabel.Text      = "  Developed by Elad Saviro | Soroka Hospital - IT Department"
$creditLabel.ForeColor = $theme.TextDisabled
$creditLabel.Font      = $theme.FontSmall
$statusStrip.Items.Add($creditLabel) | Out-Null

$form.Controls.Add($statusStrip)

# ==============================================================================
# MAIN CONTENT PANEL (holds left, middle, right)
# ==============================================================================
$contentPanel           = New-Object System.Windows.Forms.Panel
$contentPanel.Dock      = 'Fill'
$contentPanel.Padding   = New-Object System.Windows.Forms.Padding(8, 8, 8, 4)
$contentPanel.BackColor = $theme.BG
$form.Controls.Add($contentPanel)

# ==============================================================================
# LEFT PANEL - Computer Search (anchored Top, Bottom, Left)
# ==============================================================================
$leftPanel           = New-Object System.Windows.Forms.Panel
$leftPanel.Location  = New-Object System.Drawing.Point(6, 6)
$leftPanel.Size      = New-Object System.Drawing.Size(320, 725)
$leftPanel.BackColor = $theme.BG_Secondary
$contentPanel.Controls.Add($leftPanel)

$leftPanel.Controls.Add((New-ThemedLabel -Text "COMPUTER SEARCH" -X 12 -Y 12 -Title))
New-Separator -X 12 -Y 36 -W 296 -Parent $leftPanel | Out-Null

$leftPanel.Controls.Add((New-ThemedLabel -Text "Computer name, IP or filter (*):" -X 12 -Y 46 -Secondary))

$computerInputBox = New-ThemedTextBox -X 12 -Y 66 -W 220 -H 26
$script:toolTip.SetToolTip($computerInputBox, "Enter computer name, IP, or wildcard pattern. Press Enter to search.")
$leftPanel.Controls.Add($computerInputBox)

$searchButton = New-ThemedButton -Text "Search" -X 238 -Y 64 -W 74 -H 30 -Accent -Tooltip "Search Active Directory (Enter)"
$leftPanel.Controls.Add($searchButton)

$leftPanel.Controls.Add((New-ThemedLabel -Text "RESULTS" -X 12 -Y 100 -Section))

$computerListBox        = New-ThemedListBox -X 12 -Y 118 -W 296 -H 430
$leftPanel.Controls.Add($computerListBox)

$quickSep = New-Separator -X 12 -Y 558 -W 296 -Parent $leftPanel

$quickActionsLabel        = New-ThemedLabel -Text "QUICK ACTIONS" -X 12 -Y 566 -Section
$leftPanel.Controls.Add($quickActionsLabel)

$quickPingBtn        = New-ThemedButton -Text "Ping"   -X 12  -Y 584 -W 92 -H 28 -Tooltip "Continuous ping (Ctrl+P)"
$quickRDPBtn         = New-ThemedButton -Text "RDP"    -X 112 -Y 584 -W 92 -H 28 -Tooltip "Remote Desktop (Ctrl+R)"
$quickCBtn           = New-ThemedButton -Text "C$"     -X 212 -Y 584 -W 92 -H 28 -Tooltip "Open admin share (Ctrl+E)"
$leftPanel.Controls.Add($quickPingBtn)
$leftPanel.Controls.Add($quickRDPBtn)
$leftPanel.Controls.Add($quickCBtn)

# Quick actions row 2 - from CSV
$quickDamewareBtn    = New-ThemedButton -Text "DameWare" -X 12  -Y 620 -W 92 -H 28 -Tooltip "DameWare Mini Remote Control"
$quickLogonBtn       = New-ThemedButton -Text "Logon"    -X 112 -Y 620 -W 92 -H 28 -Tooltip "Query logged-on users"
$quickRestartBtn     = New-ThemedButton -Text "Restart"  -X 212 -Y 620 -W 92 -H 28 -Danger  -Tooltip "Restart remote computer"
$leftPanel.Controls.Add($quickDamewareBtn)
$leftPanel.Controls.Add($quickLogonBtn)
$leftPanel.Controls.Add($quickRestartBtn)

# Count label
$script:resultCountLabel        = New-ThemedLabel -Text "" -X 60 -Y 100 -Section
$leftPanel.Controls.Add($script:resultCountLabel)

# Context menu
$mainListContextMenu              = New-ThemedContextMenu
$mainListCopyMenuItem             = Add-ThemedMenuItem $mainListContextMenu "Copy Name"
$mainListPingMenuItem             = Add-ThemedMenuItem $mainListContextMenu "Ping"
$mainListRDPMenuItem              = Add-ThemedMenuItem $mainListContextMenu "RDP"
$mainListCShareMenuItem           = Add-ThemedMenuItem $mainListContextMenu "Open C$"
$computerListBox.ContextMenuStrip = $mainListContextMenu

# ==============================================================================
# MIDDLE PANEL - Actions (anchored all sides)
# ==============================================================================
$middlePanel           = New-Object System.Windows.Forms.Panel
$middlePanel.Location  = New-Object System.Drawing.Point(332, 6)
$middlePanel.Size      = New-Object System.Drawing.Size(504, 725)
$middlePanel.BackColor = $theme.BG_Secondary
$contentPanel.Controls.Add($middlePanel)

$middlePanel.Controls.Add((New-ThemedLabel -Text "ACTIONS" -X 12 -Y 12 -Title))

$script:selectedComputerLabel           = New-ThemedLabel -Text "No computer selected" -X 100 -Y 14 -Bold
$script:selectedComputerLabel.ForeColor = $theme.TextDisabled
$middlePanel.Controls.Add($script:selectedComputerLabel)

New-Separator -X 12 -Y 36 -W 480 -Parent $middlePanel | Out-Null
$middlePanel.Controls.Add((New-ThemedLabel -Text "Select an action for the target computer:" -X 12 -Y 44 -Secondary))

$script:backButton         = New-ThemedButton -Text "<  Back" -X 404 -Y 8 -W 90 -H 28 -Tooltip "Return to main menu (Esc)"
$script:backButton.Visible = $false
$script:backButton.Add_Click({ Switch-ToPanel -PanelName "main" })
$middlePanel.Controls.Add($script:backButton)

# ==============================================================================
# FUNCTION: Switch Panels
# ==============================================================================
function Switch-ToPanel {
    param([string]$PanelName)
    $middlePanel.Controls | Where-Object { $_.Tag -eq "ButtonPanel" } | ForEach-Object { $_.Visible = $false }
    $targetPanel = $script:cachedButtonPanels[$PanelName]
    if ($targetPanel) {
        $targetPanel.Visible       = $true
        $script:backButton.Visible = ($PanelName -ne "main")
        Set-Status "Menu: $PanelName" "Info"
    }
}

# ==============================================================================
# FUNCTION: Build Button Panel from CSV
# ==============================================================================
function New-ButtonPanel {
    param([string]$PanelCsvFile)

    $panelCsvPath = if ([System.IO.Path]::IsPathRooted($PanelCsvFile)) {
        $PanelCsvFile
    } else {
        Join-Path $PSScriptRoot $PanelCsvFile
    }

    if (-not (Test-Path $panelCsvPath)) {
        Write-Warning "Button config not found: $panelCsvPath"
        return $null
    }

    $panel            = New-Object System.Windows.Forms.Panel
    $panel.Location   = New-Object System.Drawing.Point(8, 62)
    $panel.Size       = New-Object System.Drawing.Size(488, 605)
    $panel.AutoScroll = $true
    $panel.BackColor  = $theme.BG_Secondary
    $panel.Tag        = "ButtonPanel"
    $panel.Visible    = $false
    # Prevent horizontal scrollbar when vertical scrollbar appears
    $panel.HorizontalScroll.Maximum = 0
    $panel.AutoScrollMinSize        = New-Object System.Drawing.Size(0, 0)

    $buttonConfig = Import-Csv -Path $panelCsvPath -ErrorAction SilentlyContinue
    if (-not $buttonConfig) {
        Set-Status "Failed to load buttons from: $panelCsvPath" "Warning"
        return $panel
    }

    $buttonCounter = 0
    $initialX = 4; $initialY = 4
    $currentX = $initialX; $currentY = $initialY
    $buttonHeight = $script:settings.Layout.ButtonHeight
    $buttonWidth  = $script:settings.Layout.ButtonWidth
    $columns      = [Math]::Max(1, $script:settings.Layout.ButtonColumns)
    $hMargin = 10; $vMargin = 8

    foreach ($buttonInfo in $buttonConfig) {
        $colIndex = $buttonCounter % $columns
        if ($buttonCounter -gt 0 -and $colIndex -eq 0) {
            $currentY += $buttonHeight + $vMargin
        }
        $currentX = $initialX + ($colIndex * ($buttonWidth + $hMargin))

        $btn                            = New-Object System.Windows.Forms.Button
        $btn.Text                       = $buttonInfo.ButtonText
        $btn.Location                   = New-Object System.Drawing.Point($currentX, $currentY)
        $btn.Size                       = New-Object System.Drawing.Size($buttonWidth, $buttonHeight)
        $btn.FlatStyle                  = 'Flat'
        $btn.Font                       = $theme.Font
        $btn.BackColor                  = $theme.ButtonBG
        $btn.ForeColor                  = $theme.TextPrimary
        $btn.FlatAppearance.BorderColor = $theme.ButtonBorder
        $btn.FlatAppearance.BorderSize  = 1
        $btn.TextAlign                  = 'MiddleLeft'
        $btn.Padding                    = New-Object System.Windows.Forms.Padding(10, 0, 0, 0)
        $btn.Cursor                     = [System.Windows.Forms.Cursors]::Hand
        $btn.Tag                        = @{ Action = $buttonInfo.Action; Type = $buttonInfo.Type }

        # Hover effects with closure
        $colorNormal = $theme.ButtonBG
        $colorHover  = $theme.ButtonBGHover
        $colorPress  = $theme.BG_Input
        $btn.Add_MouseEnter({ $this.BackColor = $colorHover  }.GetNewClosure())
        $btn.Add_MouseLeave({ $this.BackColor = $colorNormal }.GetNewClosure())
        $btn.Add_MouseDown( { $this.BackColor = $colorPress  }.GetNewClosure())
        $btn.Add_MouseUp(   { $this.BackColor = $colorHover  }.GetNewClosure())

        # Icon loading with proper disposal
        if ($buttonInfo.IconPath) {
            try {
                $iconPath = if ([System.IO.Path]::IsPathRooted($buttonInfo.IconPath)) {
                    $buttonInfo.IconPath
                } else {
                    Join-Path $PSScriptRoot "Icons\$($buttonInfo.IconPath)"
                }
                $icon = $null
                if ($iconPath -match ',') {
                    $parts    = $iconPath.Split(',')
                    $filePath = $parts[0]
                    if ([System.IntPtr]::Size -eq 4 -and $filePath -match 'System32') {
                        $filePath = $filePath.Replace('\System32\', '\sysnative\')
                    }
                    $extractor = New-Object System.Drawing.Icon($filePath, [int]$parts[1])
                    $icon      = $extractor.ToBitmap()
                    $extractor.Dispose()
                } elseif (Test-Path $iconPath) {
                    $icon = [System.Drawing.Image]::FromFile($iconPath)
                }
                if ($icon) {
                    $thumb = $icon.GetThumbnailImage(24, 24, $null, [IntPtr]::Zero)
                    $btn.Image             = $thumb
                    $btn.ImageAlign        = 'MiddleLeft'
                    $btn.TextImageRelation = 'ImageBeforeText'
                    $btn.Padding           = New-Object System.Windows.Forms.Padding(6, 0, 0, 0)
                    # NOTE: Don't dispose $icon here - the button holds a reference via thumbnail
                }
            } catch {
                Write-Warning "Icon load failed for '$($btn.Text)': $($_.Exception.Message)"
            }
        }

        # Click handler
        $btn.Add_Click({
            $tagData        = $this.Tag
            $actionTemplate = $tagData.Action
            $actionType     = $tagData.Type

            if ($null -eq $script:selectedComputer -and $actionTemplate -match '\$ComputerName') {
                [System.Windows.Forms.MessageBox]::Show(
                    "Please select a computer first.",
                    "No Target", "OK", "Warning"
                )
                return
            }

            $resolvedAction = $actionTemplate -replace '\$ComputerName', $script:selectedComputer
            Set-Status "Running: $($this.Text) on $script:selectedComputer" "Info"

            try {
                switch ($actionType) {
                    "PowerShell"   { & ([ScriptBlock]::Create($resolvedAction)) }
                    "CMD"          { Start-Process cmd.exe -ArgumentList $resolvedAction }
                    "CMD-Close"    { Start-Process cmd.exe -ArgumentList $resolvedAction }
                    "PS-NewWindow" {
                        $wrapped = "try { $resolvedAction } catch { Write-Warning 'Error:'; Write-Error `$_.Exception.Message } finally { Write-Host '--- Done. Closing in 10s ---' -ForegroundColor Green; Start-Sleep 10 }"
                        $encoded = [Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes($wrapped))
                        Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -EncodedCommand $encoded"
                    }
                    "OpenSubMenu"  { Switch-ToPanel -PanelName $resolvedAction }
                    "ShowMainMenu" { Switch-ToPanel -PanelName "main" }
                    default {
                        [System.Windows.Forms.MessageBox]::Show(
                            "Unknown action type: '$actionType'",
                            "Configuration Error", "OK", "Error"
                        )
                    }
                }
                if ($actionType -notin @("OpenSubMenu", "ShowMainMenu")) {
                    Set-Status "Done: $($this.Text)" "Success"
                }
            } catch {
                Set-Status "Error: $($_.Exception.Message)" "Error"
                [System.Windows.Forms.MessageBox]::Show(
                    "Action failed:`n$($_.Exception.Message)",
                    "Error", "OK", "Error"
                )
            }
        })

        $panel.Controls.Add($btn)
        $buttonCounter++
    }
    return $panel
}

# Build and cache panels
if (Test-Path $csvPath) {
    $mainButtonPanel = New-ButtonPanel -PanelCsvFile "buttons.csv"
    if ($mainButtonPanel) {
        $middlePanel.Controls.Add($mainButtonPanel)
        $script:cachedButtonPanels["main"] = $mainButtonPanel
    }

    $mainButtonConfig = Import-Csv -Path $csvPath -ErrorAction SilentlyContinue
    if ($mainButtonConfig) {
        $mainButtonConfig |
            Where-Object { $_.Type -eq "OpenSubMenu" } |
            Select-Object -ExpandProperty Action -Unique |
            ForEach-Object {
                if (-not $script:cachedButtonPanels.ContainsKey($_)) {
                    $subPanel = New-ButtonPanel -PanelCsvFile $_
                    if ($subPanel) {
                        $middlePanel.Controls.Add($subPanel)
                        $script:cachedButtonPanels[$_] = $subPanel
                    }
                }
            }
    }
    Switch-ToPanel -PanelName "main"
} else {
    $noConfigLabel = New-ThemedLabel -Text "buttons.csv not found in script directory." -X 12 -Y 70 -Secondary
    $middlePanel.Controls.Add($noConfigLabel)
    Set-Status "Warning: buttons.csv not found" "Warning"
}

# ==============================================================================
# INFO PANEL - PC Information (auto-fills on computer select)
# ==============================================================================
$infoPanel           = New-Object System.Windows.Forms.Panel
$infoPanel.Location  = New-Object System.Drawing.Point(842, 6)
$infoPanel.Size      = New-Object System.Drawing.Size(280, 456)
$infoPanel.BackColor = $theme.BG_Secondary
$contentPanel.Controls.Add($infoPanel)

$infoPanel.Controls.Add((New-ThemedLabel -Text "PC INFO" -X 12 -Y 12 -Title))
New-Separator -X 12 -Y 36 -W 256 -Parent $infoPanel | Out-Null

$script:infoComputerLabel           = New-Object System.Windows.Forms.Label
$script:infoComputerLabel.Text      = "No computer selected"
$script:infoComputerLabel.Location  = New-Object System.Drawing.Point(12, 44)
$script:infoComputerLabel.Size      = New-Object System.Drawing.Size(256, 18)
$script:infoComputerLabel.Font      = $theme.FontBold
$script:infoComputerLabel.ForeColor = $theme.TextDisabled
$script:infoComputerLabel.BackColor = [System.Drawing.Color]::Transparent
$infoPanel.Controls.Add($script:infoComputerLabel)

New-Separator -X 12 -Y 66 -W 256 -Parent $infoPanel | Out-Null

# --- NETWORK section ---
$infoPanel.Controls.Add((New-ThemedLabel -Text "NETWORK" -X 12 -Y 74 -Section))
$script:infoIPLabel   = New-InfoRow -Label "IP Address:" -Y 90  -Parent $infoPanel
$script:infoMACLabel  = New-InfoRow -Label "MAC Addr:"  -Y 110 -Parent $infoPanel
$script:infoLinkLabel = New-InfoRow -Label "Link Speed:" -Y 130 -Parent $infoPanel

New-Separator -X 12 -Y 152 -W 256 -Parent $infoPanel | Out-Null

# --- STORAGE section ---
$infoPanel.Controls.Add((New-ThemedLabel -Text "STORAGE  (C:)" -X 12 -Y 160 -Section))
$script:infoDiskSizeLabel = New-InfoRow -Label "Total Size:"  -Y 176 -Parent $infoPanel
$script:infoDiskFreeLabel = New-InfoRow -Label "Free Space:"  -Y 196 -Parent $infoPanel
$script:infoDiskPctLabel  = New-InfoRow -Label "Free:"        -Y 216 -Parent $infoPanel
$script:infoDiskPctLabel.ForeColor = $theme.TextMuted

New-Separator -X 12 -Y 238 -W 256 -Parent $infoPanel | Out-Null

# --- SYSTEM section ---
$infoPanel.Controls.Add((New-ThemedLabel -Text "SYSTEM" -X 12 -Y 246 -Section))
$script:infoOSLabel    = New-InfoRow -Label "OS:"    -Y 262 -Parent $infoPanel
$script:infoRAMLabel   = New-InfoRow -Label "RAM:"   -Y 282 -Parent $infoPanel
$script:infoCPULabel   = New-InfoRow -Label "CPU:"   -Y 302 -Parent $infoPanel
$script:infoModelLabel = New-InfoRow -Label "Model:" -Y 322 -Parent $infoPanel

New-Separator -X 12 -Y 346 -W 256 -Parent $infoPanel | Out-Null

# Refresh button
$infoRefreshBtn = New-ThemedButton -Text "Refresh" -X 12 -Y 354 -W 256 -H 28 -Accent -Tooltip "Re-fetch all PC information"
$infoPanel.Controls.Add($infoRefreshBtn)

# Copy IP button
$infoCopyIPBtn = New-ThemedButton -Text "Copy IP" -X 12 -Y 390 -W 124 -H 28 -Tooltip "Copy IP address to clipboard"
$infoPanel.Controls.Add($infoCopyIPBtn)

# Copy MAC button
$infoCopyMACBtn = New-ThemedButton -Text "Copy MAC" -X 144 -Y 390 -W 124 -H 28 -Tooltip "Copy MAC address to clipboard"
$infoPanel.Controls.Add($infoCopyMACBtn)

# Status / last-updated label
$script:infoStatusLabel           = New-Object System.Windows.Forms.Label
$script:infoStatusLabel.Text      = "Select a computer to load info"
$script:infoStatusLabel.Location  = New-Object System.Drawing.Point(12, 426)
$script:infoStatusLabel.Size      = New-Object System.Drawing.Size(256, 32)
$script:infoStatusLabel.Font      = $theme.FontSmall
$script:infoStatusLabel.ForeColor = $theme.TextDisabled
$script:infoStatusLabel.BackColor = [System.Drawing.Color]::Transparent
$script:infoStatusLabel.AutoSize  = $false
$infoPanel.Controls.Add($script:infoStatusLabel)

# ==============================================================================
# LOGON PANEL - Logged-on Users (below info panel)
# ==============================================================================
$logonPanel           = New-Object System.Windows.Forms.Panel
$logonPanel.Location  = New-Object System.Drawing.Point(842, 468)
$logonPanel.Size      = New-Object System.Drawing.Size(280, 263)
$logonPanel.BackColor = $theme.BG_Secondary
$contentPanel.Controls.Add($logonPanel)

$logonPanel.Controls.Add((New-ThemedLabel -Text "LOGGED ON USERS" -X 12 -Y 10 -Title))
New-Separator -X 12 -Y 32 -W 256 -Parent $logonPanel | Out-Null

$script:logonUsersListBox = New-ThemedListBox -X 12 -Y 40 -W 256 -H 110
$script:logonUsersListBox.Font = $theme.FontMonoSmall
$logonPanel.Controls.Add($script:logonUsersListBox)

# Context menu for logon listbox
$logonContextMenu                         = New-ThemedContextMenu
$logonCopyMenuItem                        = Add-ThemedMenuItem $logonContextMenu "Copy Username"
$logonLogoffMenuItem                      = Add-ThemedMenuItem $logonContextMenu "Logoff Session"
$script:logonUsersListBox.ContextMenuStrip = $logonContextMenu

# Select the right-clicked item before the menu opens
$script:logonUsersListBox.Add_MouseDown({
    param($s, $e)
    if ($e.Button -eq [System.Windows.Forms.MouseButtons]::Right) {
        $i = $script:logonUsersListBox.IndexFromPoint($e.Location)
        if ($i -ne [System.Windows.Forms.ListBox]::NoMatches) {
            $script:logonUsersListBox.SelectedIndex = $i
        }
    }
})

# Logoff disconnected sessions button
$logonRefreshBtn  = New-ThemedButton -Text "Refresh"           -X 12  -Y 158 -W 122 -H 28 -Accent   -Tooltip "Re-query logged-on users"
$logonLogoffBtn   = New-ThemedButton -Text "Logoff Disc."      -X 142 -Y 158 -W 126 -H 28 -Danger   -Tooltip "Logoff all Disconnected sessions"
$logonPanel.Controls.Add($logonRefreshBtn)
$logonPanel.Controls.Add($logonLogoffBtn)

$script:logonStatusLabel           = New-Object System.Windows.Forms.Label
$script:logonStatusLabel.Text      = "Select a computer"
$script:logonStatusLabel.Location  = New-Object System.Drawing.Point(12, 192)
$script:logonStatusLabel.Size      = New-Object System.Drawing.Size(256, 18)
$script:logonStatusLabel.Font      = $theme.FontSmall
$script:logonStatusLabel.ForeColor = $theme.TextDisabled
$script:logonStatusLabel.BackColor = [System.Drawing.Color]::Transparent
$logonPanel.Controls.Add($script:logonStatusLabel)

# ==============================================================================
# RIGHT PANEL - History & Favorites (anchored Top, Bottom, Right)
# ==============================================================================
$rightPanel           = New-Object System.Windows.Forms.Panel
$rightPanel.Location  = New-Object System.Drawing.Point(1128, 6)
$rightPanel.Size      = New-Object System.Drawing.Size(320, 725)
$rightPanel.BackColor = $theme.BG_Secondary
$contentPanel.Controls.Add($rightPanel)

$rightPanel.Controls.Add((New-ThemedLabel -Text "HISTORY & FAVORITES" -X 12 -Y 12 -Title))
New-Separator -X 12 -Y 36 -W 296 -Parent $rightPanel | Out-Null

$rightPanel.Controls.Add((New-ThemedLabel -Text "RECENT" -X 12 -Y 44 -Section))

$historyListBox        = New-ThemedListBox -X 12 -Y 62 -W 296 -H 185 -SelectionMode 'MultiExtended'
$rightPanel.Controls.Add($historyListBox)

$deleteHistoryButton        = New-ThemedButton -Text "Delete Selected" -X 12  -Y 252 -W 143 -H 28 -Tooltip "Remove selected items from history"
$clearHistoryButton         = New-ThemedButton -Text "Clear All"       -X 165 -Y 252 -W 143 -H 28 -Danger -Tooltip "Clear entire history"
$rightPanel.Controls.Add($deleteHistoryButton)
$rightPanel.Controls.Add($clearHistoryButton)

$addToFavoritesButton        = New-ThemedButton -Text "+ Add to Favorites" -X 12 -Y 288 -W 296 -H 28 -Accent -Tooltip "Add selected computer(s) to favorites"
$rightPanel.Controls.Add($addToFavoritesButton)

New-Separator -X 12 -Y 324 -W 296 -Parent $rightPanel | Out-Null

$rightPanel.Controls.Add((New-ThemedLabel -Text "FAVORITES" -X 12 -Y 332 -Section))

$favoritesListBox        = New-ThemedListBox -X 12 -Y 350 -W 296 -H 250
$rightPanel.Controls.Add($favoritesListBox)

$removeFavoriteButton        = New-ThemedButton -Text "Remove Favorite" -X 12 -Y 606 -W 296 -H 28 -Tooltip "Remove selected favorite"
$rightPanel.Controls.Add($removeFavoriteButton)

# Context menus
$historyContextMenu              = New-ThemedContextMenu
$historyCopyMenuItem             = Add-ThemedMenuItem $historyContextMenu "Copy Name"
$historyPingMenuItem             = Add-ThemedMenuItem $historyContextMenu "Ping"
$historyRDPMenuItem              = Add-ThemedMenuItem $historyContextMenu "RDP"
$historyListBox.ContextMenuStrip = $historyContextMenu

$favoritesContextMenu              = New-ThemedContextMenu
$favoritesCopyMenuItem             = Add-ThemedMenuItem $favoritesContextMenu "Copy Name"
$favoritesPingMenuItem             = Add-ThemedMenuItem $favoritesContextMenu "Ping"
$favoritesRDPMenuItem              = Add-ThemedMenuItem $favoritesContextMenu "RDP"
$favoritesListBox.ContextMenuStrip = $favoritesContextMenu

# ==============================================================================
# DATA FUNCTIONS
# ==============================================================================
function Load-History {
    if (Test-Path $historyFilePath) {
        try {
            $lines = [System.IO.File]::ReadAllLines($historyFilePath)

            # Auto-clear old items if configured (based on file modification time as proxy)
            $autoClearDays = $script:settings.History.AutoClearDays
            if ($autoClearDays -gt 0) {
                $fileAge = (Get-Date) - (Get-Item $historyFilePath).LastWriteTime
                if ($fileAge.TotalDays -gt $autoClearDays) {
                    # File is older than threshold - keep only first 10 items
                    $lines = $lines | Select-Object -First 10
                }
            }

            $maxItems = $script:settings.History.MaxItems
            $count = 0
            foreach ($line in $lines) {
                $clean = $line.Trim()
                if ($clean) {
                    if ($maxItems -gt 0 -and $count -ge $maxItems) { break }
                    $historyListBox.Items.Add($clean) | Out-Null
                    $count++
                }
            }
        } catch {
            Set-Status "Failed to load history: $($_.Exception.Message)" "Warning"
        }
    }
}

function Save-History {
    try {
        $items = @()
        foreach ($item in $historyListBox.Items) { $items += $item.ToString() }
        [System.IO.File]::WriteAllLines($historyFilePath, $items)
    } catch {
        Set-Status "Error saving history: $($_.Exception.Message)" "Error"
    }
}

function Load-Favorites {
    if (Test-Path $favoritesFilePath) {
        try {
            $lines = [System.IO.File]::ReadAllLines($favoritesFilePath)
            foreach ($line in $lines) {
                $clean = $line.Trim()
                if ($clean) { $favoritesListBox.Items.Add($clean) | Out-Null }
            }
        } catch {
            Set-Status "Failed to load favorites: $($_.Exception.Message)" "Warning"
        }
    }
}

function Save-Favorites {
    try {
        $items = @()
        foreach ($item in $favoritesListBox.Items) { $items += $item.ToString() }
        [System.IO.File]::WriteAllLines($favoritesFilePath, $items)
    } catch {
        Set-Status "Error saving favorites: $($_.Exception.Message)" "Error"
    }
}

function Select-Computer {
    param([string]$ComputerName)
    $clean = $ComputerName.Trim()
    if ([string]::IsNullOrWhiteSpace($clean)) { return }
    $script:selectedComputer                = $clean
    $form.Text                              = "Remote Admin Tool v3.0  -  [$clean]"
    # Show "pinging..." state while we check
    $script:selectedComputerLabel.Text      = "> $clean  [...]"
    $script:selectedComputerLabel.ForeColor = $theme.Warning
    $script:statusComputer.Text             = "Target: $clean  [pinging...]  "
    $script:statusComputer.ForeColor        = $theme.Warning
    # Add to history (move to top if exists)
    $existingIdx = -1
    for ($i = 0; $i -lt $historyListBox.Items.Count; $i++) {
        if ($historyListBox.Items[$i].ToString() -eq $clean) { $existingIdx = $i; break }
    }
    if ($existingIdx -gt 0) {
        $historyListBox.Items.RemoveAt($existingIdx)
        $historyListBox.Items.Insert(0, $clean)
    } elseif ($existingIdx -lt 0) {
        $historyListBox.Items.Insert(0, $clean)
    }
    Set-Status "Selected: $clean" "Success"
    # Fire async ping
    Start-AsyncPing -ComputerName $clean
    # Fire async info fetch
    Start-InfoFetch -ComputerName $clean
    # Fire async logon fetch
    Start-LogonFetch -ComputerName $clean
    # Start logon auto-refresh if enabled
    $script:logonAutoRefreshTimer.Stop()
    if ($script:settings.Logon.AutoRefresh) {
        $script:logonAutoRefreshTimer.Interval = [Math]::Max(10000, $script:settings.Logon.RefreshIntervalSec * 1000)
        $script:logonAutoRefreshTimer.Start()
    }
    # Remember last computer
    if ($script:settings.Behavior.RememberLastComputer) {
        $script:settings.Behavior.LastComputer = $clean
        Save-Settings
    }
}

# ==============================================================================
# KEYBOARD SHORTCUTS (reads from settings)
# ==============================================================================
# Helper: Parse shortcut string like "Ctrl+F" or "Ctrl+Shift+P" into modifier+key
function Test-Shortcut {
    param([System.Windows.Forms.KeyEventArgs]$Event, [string]$ShortcutString)
    if ([string]::IsNullOrWhiteSpace($ShortcutString)) { return $false }
    $parts = $ShortcutString.Split('+') | ForEach-Object { $_.Trim() }
    $needCtrl  = $parts -contains 'Ctrl'
    $needShift = $parts -contains 'Shift'
    $needAlt   = $parts -contains 'Alt'
    $keyPart   = $parts | Where-Object { $_ -notin @('Ctrl','Shift','Alt') } | Select-Object -Last 1
    if (-not $keyPart) { return $false }
    return (
        ($Event.Control -eq $needCtrl) -and
        ($Event.Shift   -eq $needShift) -and
        ($Event.Alt     -eq $needAlt) -and
        ($Event.KeyCode -eq $keyPart)
    )
}

$form.Add_KeyDown({
    param($s, $e)
    # Search (also keep Ctrl+L as built-in alias)
    if ((Test-Shortcut $e $script:settings.Shortcuts.Search) -or ($e.Control -and $e.KeyCode -eq 'L')) {
        $e.SuppressKeyPress = $true
        $computerInputBox.Focus()
        $computerInputBox.SelectAll()
    }
    # Ping
    if (Test-Shortcut $e $script:settings.Shortcuts.Ping) {
        $e.SuppressKeyPress = $true
        $quickPingBtn.PerformClick()
    }
    # RDP
    if (Test-Shortcut $e $script:settings.Shortcuts.RDP) {
        $e.SuppressKeyPress = $true
        $quickRDPBtn.PerformClick()
    }
    # C$
    if (Test-Shortcut $e $script:settings.Shortcuts.CShare) {
        $e.SuppressKeyPress = $true
        $quickCBtn.PerformClick()
    }
    # Escape => back button or clear search (always built-in)
    if ($e.KeyCode -eq 'Escape') {
        if ($script:backButton.Visible) {
            $script:backButton.PerformClick()
        } else {
            $computerInputBox.Text = ""
            $computerInputBox.Focus()
        }
    }
})

# ==============================================================================
# EVENT HANDLERS
# ==============================================================================

# --- Core search function (called by button, Enter, and debounce timer) ---
function Invoke-ComputerSearch {
    $userInput = $computerInputBox.Text.Trim()

    # If empty, clear results and reset
    if ([string]::IsNullOrWhiteSpace($userInput)) {
        $computerListBox.Items.Clear()
        $script:resultCountLabel.Text = ""
        $script:lastSearchText = ""
        Set-Status $script:defaultStatus "Info"
        return
    }

    # Skip if we already searched this exact text
    if ($userInput -eq $script:lastSearchText) { return }
    $script:lastSearchText = $userInput

    $adFilterName = $userInput
    Set-Status "Searching: $userInput ..." "Info"
    $computerListBox.Items.Clear()
    $script:resultCountLabel.Text = ""

    # IP address handling
    if ($userInput -match '^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$') {
        $computerListBox.Items.Add("Resolving IP...")
        $form.Update()
        try {
            $dnsEntry     = [System.Net.Dns]::GetHostEntry($userInput)
            $adFilterName = ($dnsEntry.HostName).Split('.')[0]
            Set-Status "IP resolved to $adFilterName" "Success"
        } catch {
            $computerListBox.Items.Clear()
            $computerListBox.Items.Add($userInput)
            $computerListBox.SelectedIndex = 0
            Select-Computer -ComputerName $userInput
            Set-Status "IP not in DNS - using directly" "Warning"
            $script:resultCountLabel.Text = "(1)"
            return
        }
    }

    $computerListBox.Items.Add("Searching AD...")
    $form.Update()

    try {
        $escapedFilter = Escape-LDAPFilter -Value $adFilterName
        $adParams = @{
            Filter     = "Name -like '*$escapedFilter*'"
            Properties = @("Name")
        }
        # Apply SearchBase from settings if configured
        $sb = $script:settings.Search.SearchBase
        if ($sb -and $sb.Trim() -ne "") {
            $adParams.SearchBase = $sb.Trim()
        }
        $maxR = $script:settings.Search.MaxResults
        if ($maxR -gt 0) {
            $adParams.ResultSetSize = $maxR
        }
        $computers = Get-ADComputer @adParams |
                     ForEach-Object { $_.Name.Trim() } |
                     Sort-Object
        $computerListBox.Items.Clear()

        if ($computers) {
            $count = @($computers).Count
            $computers | ForEach-Object { $computerListBox.Items.Add($_) | Out-Null }
            $script:resultCountLabel.Text = "($count)"
            Set-Status "Found $count computer(s) matching '$adFilterName'" "Success"
            if ($count -eq 1) {
                $computerListBox.SelectedIndex = 0
            }
        } else {
            $computerListBox.Items.Add("No computers found")
            $script:resultCountLabel.Text = "(0)"
            Set-Status "No results for '$adFilterName'" "Warning"
        }
    } catch {
        $computerListBox.Items.Clear()
        $computerListBox.Items.Add("AD search error")
        Set-Status "AD Error: $($_.Exception.Message)" "Error"
    }
}

# --- Enter key: immediate search (bypass debounce) ---
$computerInputBox.Add_KeyDown({
    param($s, $e)
    if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {
        $e.SuppressKeyPress = $true
        $script:searchTimer.Stop()
        $script:lastSearchText = ""   # Force re-search even if same text
        Invoke-ComputerSearch
    }
})

# --- TextChanged: debounced auto-search ---
$computerInputBox.Add_TextChanged({
    $text = $computerInputBox.Text.Trim()
    $script:searchTimer.Stop()

    if ([string]::IsNullOrWhiteSpace($text)) {
        # Immediately clear when input is empty
        $computerListBox.Items.Clear()
        $script:resultCountLabel.Text = ""
        $script:lastSearchText = ""
        Set-Status $script:defaultStatus "Info"
        return
    }

    if ($text.Length -ge $script:minAutoSearchChars -and $script:settings.Search.AutoSearchEnabled) {
        # Restart debounce timer
        $script:searchTimer.Start()
    }
})

# --- Search button: immediate search ---
$searchButton.Add_Click({
    $script:searchTimer.Stop()
    $script:lastSearchText = ""   # Force re-search
    Invoke-ComputerSearch
})

$computerListBox.Add_SelectedIndexChanged({
    if ($computerListBox.SelectedItem) {
        $val = $computerListBox.SelectedItem.ToString()
        $skipPrefixes = @("Resolving", "Searching", "No computers", "AD search")
        $skip = $false
        foreach ($p in $skipPrefixes) { if ($val.StartsWith($p)) { $skip = $true; break } }
        if (-not $skip) { Select-Computer -ComputerName $val }
    }
})

$computerListBox.Add_MouseDown({
    param($s, $e)
    if ($e.Button -eq [System.Windows.Forms.MouseButtons]::Right) {
        $i = $computerListBox.IndexFromPoint($e.Location)
        if ($i -ne [System.Windows.Forms.ListBox]::NoMatches) { $computerListBox.SelectedIndex = $i }
    }
})

# Main list context menu handlers
$mainListCopyMenuItem.Add_Click({
    if ($computerListBox.SelectedItem) {
        [System.Windows.Forms.Clipboard]::SetText($computerListBox.SelectedItem.ToString().Trim())
    }
})
$mainListPingMenuItem.Add_Click({
    if ($script:selectedComputer) {
        Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -Command `"ping -t $script:selectedComputer; pause`""
    }
})
$mainListRDPMenuItem.Add_Click({
    if ($script:selectedComputer) { Start-RDPSession -ComputerName $script:selectedComputer }
})
$mainListCShareMenuItem.Add_Click({
    if ($script:selectedComputer) { Start-Process "explorer.exe" -ArgumentList "\\$script:selectedComputer\C$" }
})

# Quick action buttons
$quickPingBtn.Add_Click({
    if ($script:selectedComputer) {
        Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -Command `"ping -t $script:selectedComputer; pause`""
    } else {
        [System.Windows.Forms.MessageBox]::Show("Select a computer first.", "No Target", "OK", "Warning")
    }
})
$quickRDPBtn.Add_Click({
    Start-RDPSession -ComputerName $script:selectedComputer
})
$quickCBtn.Add_Click({
    if ($script:selectedComputer) { Start-Process "explorer.exe" -ArgumentList "\\$script:selectedComputer\C$" }
    else { [System.Windows.Forms.MessageBox]::Show("Select a computer first.", "No Target", "OK", "Warning") }
})

$quickDamewareBtn.Add_Click({
    Start-DameWareSession -ComputerName $script:selectedComputer
})
$quickLogonBtn.Add_Click({
    if ($script:selectedComputer) {
        Start-Process cmd.exe -ArgumentList "/k query user /server:$script:selectedComputer"
    } else {
        [System.Windows.Forms.MessageBox]::Show("Select a computer first.", "No Target", "OK", "Warning")
    }
})
$quickRestartBtn.Add_Click({
    if ($script:selectedComputer) {
        $delay = $script:settings.Restart.DelaySeconds
        $delayText = if ($delay -eq 0) { "immediately" } else { "in $delay seconds" }
        $msgText   = if ($script:settings.Restart.ShowMessage) { "`nA message will be shown to the user." } else { "" }

        $confirm = [System.Windows.Forms.MessageBox]::Show(
            "Restart $script:selectedComputer $delayText?$msgText",
            "Confirm Restart", "YesNo", "Warning")
        if ($confirm -eq 'Yes') {
            $shutArgs = "/m \\$script:selectedComputer /r /t $delay"
            if ($script:settings.Restart.ShowMessage -and $script:settings.Restart.DefaultMessage) {
                $shutArgs += " /c `"$($script:settings.Restart.DefaultMessage)`""
            }
            Start-Process cmd.exe -ArgumentList "/c shutdown $shutArgs"
            Set-Status "Restart initiated: $script:selectedComputer (delay: ${delay}s)" "Warning"
        }
    } else {
        [System.Windows.Forms.MessageBox]::Show("Select a computer first.", "No Target", "OK", "Warning")
    }
})

$infoRefreshBtn.Add_Click({
    if ($script:selectedComputer) {
        Start-InfoFetch -ComputerName $script:selectedComputer
    } else {
        Set-Status "No computer selected - nothing to refresh" "Warning"
    }
})
$infoCopyIPBtn.Add_Click({
    $ip = $script:infoIPLabel.Text
    if ($ip -and $ip -ne [char]0x2014 -and $ip -ne "Loading..." -and $ip -ne "N/A") {
        [System.Windows.Forms.Clipboard]::SetText($ip)
        Set-Status "Copied IP: $ip" "Success"
    } else {
        Set-Status "No IP address available to copy" "Warning"
    }
})
$infoCopyMACBtn.Add_Click({
    $mac = $script:infoMACLabel.Text
    if ($mac -and $mac -ne [char]0x2014 -and $mac -ne "Loading..." -and $mac -ne "N/A") {
        [System.Windows.Forms.Clipboard]::SetText($mac)
        Set-Status "Copied MAC: $mac" "Success"
    } else {
        Set-Status "No MAC address available to copy" "Warning"
    }
})

$logonRefreshBtn.Add_Click({
    if ($script:selectedComputer) {
        Start-LogonFetch -ComputerName $script:selectedComputer
    } else {
        Set-Status "No computer selected" "Warning"
    }
})

$logonCopyMenuItem.Add_Click({
    $idx = $script:logonUsersListBox.SelectedIndex
    if ($idx -ge 0 -and $idx -lt $script:logonRows.Count) {
        $username = $script:logonRows[$idx].Username
        if ($username) {
            [System.Windows.Forms.Clipboard]::SetText($username)
            Set-Status "Copied: $username" "Success"
        }
    }
})

$logonLogoffMenuItem.Add_Click({
    $idx = $script:logonUsersListBox.SelectedIndex
    if ($idx -lt 0 -or $idx -ge $script:logonRows.Count) {
        [System.Windows.Forms.MessageBox]::Show("Select a session first.", "No Selection", "OK", "Warning")
        return
    }
    if (-not $script:selectedComputer) {
        [System.Windows.Forms.MessageBox]::Show("No computer selected.", "No Target", "OK", "Warning")
        return
    }
    $row = $script:logonRows[$idx]
    $confirm = [System.Windows.Forms.MessageBox]::Show(
        "Logoff user '$($row.Username)' (Session ID: $($row.SessionID)) from $script:selectedComputer?",
        "Confirm Logoff", "YesNo", "Warning")
    if ($confirm -ne 'Yes') { return }

    try {
        $target = $script:selectedComputer
        $sid    = $row.SessionID
        Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -Command `"rwinsta /server:$target $sid`""
        Set-Status "Logged off session $sid ($($row.Username)) on $target" "Success"
        Start-Sleep -Milliseconds 1500
        Start-LogonFetch -ComputerName $target
    } catch {
        Set-Status "Logoff failed: $($_.Exception.Message)" "Error"
    }
})

$logonLogoffBtn.Add_Click({
    if (-not $script:selectedComputer) {
        [System.Windows.Forms.MessageBox]::Show("Select a computer first.", "No Target", "OK", "Warning")
        return
    }
    $confirm = [System.Windows.Forms.MessageBox]::Show(
        "Logoff all Disconnected sessions on $script:selectedComputer?",
        "Confirm Logoff", "YesNo", "Warning")
    if ($confirm -ne 'Yes') { return }

    Set-Status "Logging off disconnected sessions on $script:selectedComputer..." "Info"
    $target = $script:selectedComputer
    $wrapped = @"
`$qOut = quser.exe /server:$target 2>`$null
if (-not `$qOut) { Write-Host 'No sessions found.'; Start-Sleep 3; exit }
`$qOut | Select-Object -Skip 1 | Where-Object { `$_ -match 'Disc' } | ForEach-Object {
    `$parts = `$_.Trim() -split '\s+'
    `$sid = `$parts[2]
    if (`$sid -match '^\d+`$') {
        Write-Host "Logging off session `$sid..."
        rwinsta.exe /server:$target `$sid
    }
}
Write-Host '--- Done ---' -ForegroundColor Green
Start-Sleep 3
"@
    $encoded = [Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes($wrapped))
    Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -EncodedCommand $encoded"
    Start-Sleep -Milliseconds 3500
    Start-LogonFetch -ComputerName $script:selectedComputer
})

# History handlers
$historyListBox.Add_DoubleClick({
    if ($historyListBox.SelectedItem) {
        $computerInputBox.Text = $historyListBox.SelectedItem.ToString().Trim()
        $searchButton.PerformClick()
    }
})
$historyListBox.Add_SelectedIndexChanged({
    if ($historyListBox.SelectedItem -and $historyListBox.Focused) {
        $name = $historyListBox.SelectedItem.ToString().Trim()
        Select-Computer -ComputerName $name
        $computerListBox.Items.Clear()
        $computerListBox.Items.Add($name)
        $computerListBox.SelectedIndex = 0
    }
})
$historyListBox.Add_MouseDown({
    param($s, $e)
    if ($e.Button -eq [System.Windows.Forms.MouseButtons]::Right) {
        $i = $historyListBox.IndexFromPoint($e.Location)
        if ($i -ne [System.Windows.Forms.ListBox]::NoMatches) { $historyListBox.SelectedIndex = $i }
    }
})

$historyCopyMenuItem.Add_Click({
    if ($historyListBox.SelectedItem) {
        [System.Windows.Forms.Clipboard]::SetText($historyListBox.SelectedItem.ToString().Trim())
    }
})
$historyPingMenuItem.Add_Click({
    if ($historyListBox.SelectedItem) {
        $target = $historyListBox.SelectedItem.ToString().Trim()
        Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -Command `"ping -t $target; pause`""
    }
})
$historyRDPMenuItem.Add_Click({
    if ($historyListBox.SelectedItem) {
        Start-RDPSession -ComputerName $historyListBox.SelectedItem.ToString().Trim()
    }
})

$deleteHistoryButton.Add_Click({
    if ($historyListBox.SelectedItems.Count -gt 0) {
        $toRemove = @($historyListBox.SelectedItems)
        foreach ($item in $toRemove) { $historyListBox.Items.Remove($item) }
        Save-History
        Set-Status "Removed $($toRemove.Count) item(s) from history" "Success"
    }
})
$clearHistoryButton.Add_Click({
    $res = [System.Windows.Forms.MessageBox]::Show(
        "Clear all search history?`n(Favorites will not be affected)",
        "Confirm", "YesNo", "Warning")
    if ($res -eq 'Yes') {
        $historyListBox.Items.Clear()
        Save-History
        Set-Status "History cleared" "Success"
    }
})

$addToFavoritesButton.Add_Click({
    $itemsToAdd = if ($historyListBox.SelectedItems.Count -gt 0) {
        @($historyListBox.SelectedItems)
    } elseif ($computerListBox.SelectedItems.Count -gt 0) {
        @($computerListBox.SelectedItems)
    } else { @() }

    if ($itemsToAdd.Count -eq 0 -and $script:selectedComputer) {
        $itemsToAdd = @($script:selectedComputer)
    }

    $added = 0
    foreach ($item in $itemsToAdd) {
        $clean = $item.ToString().Trim()
        if ($clean -and -not ($favoritesListBox.Items.Contains($clean))) {
            $favoritesListBox.Items.Insert(0, $clean)
            $added++
        }
    }
    if ($added -gt 0) {
        Save-Favorites
        Set-Status "Added $added favorite(s)" "Success"
    } elseif ($itemsToAdd.Count -gt 0) {
        Set-Status "Already in favorites" "Warning"
    } else {
        Set-Status "Nothing to add - select a computer first" "Warning"
    }
})

# Favorites handlers
$favoritesListBox.Add_SelectedIndexChanged({
    if ($favoritesListBox.SelectedItem -and $favoritesListBox.Focused) {
        $name = $favoritesListBox.SelectedItem.ToString().Trim()
        Select-Computer -ComputerName $name
        $computerListBox.Items.Clear()
        $computerListBox.Items.Add($name)
        $computerListBox.SelectedIndex = 0
    }
})
$favoritesListBox.Add_DoubleClick({
    if ($favoritesListBox.SelectedItem) {
        $computerInputBox.Text = $favoritesListBox.SelectedItem.ToString().Trim()
        $searchButton.PerformClick()
    }
})
$favoritesListBox.Add_MouseDown({
    param($s, $e)
    if ($e.Button -eq [System.Windows.Forms.MouseButtons]::Right) {
        $i = $favoritesListBox.IndexFromPoint($e.Location)
        if ($i -ne [System.Windows.Forms.ListBox]::NoMatches) { $favoritesListBox.SelectedIndex = $i }
    }
})
$favoritesCopyMenuItem.Add_Click({
    if ($favoritesListBox.SelectedItem) {
        [System.Windows.Forms.Clipboard]::SetText($favoritesListBox.SelectedItem.ToString().Trim())
    }
})
$favoritesPingMenuItem.Add_Click({
    if ($favoritesListBox.SelectedItem) {
        $target = $favoritesListBox.SelectedItem.ToString().Trim()
        Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -Command `"ping -t $target; pause`""
    }
})
$favoritesRDPMenuItem.Add_Click({
    if ($favoritesListBox.SelectedItem) {
        Start-RDPSession -ComputerName $favoritesListBox.SelectedItem.ToString().Trim()
    }
})
$removeFavoriteButton.Add_Click({
    if ($favoritesListBox.SelectedItem) {
        $name = $favoritesListBox.SelectedItem.ToString()
        $favoritesListBox.Items.Remove($favoritesListBox.SelectedItem)
        Save-Favorites
        Set-Status "Removed '$name' from favorites" "Success"
    }
})

# ==============================================================================
# FORM LIFECYCLE
# ==============================================================================
$form.Add_Load({
    Load-History
    Load-Favorites
    Set-Status $script:defaultStatus "Info"
    # Restore last selected computer if enabled
    if ($script:settings.Behavior.RememberLastComputer -and $script:settings.Behavior.LastComputer) {
        $lastPC = $script:settings.Behavior.LastComputer
        $computerInputBox.Text = $lastPC
        Select-Computer -ComputerName $lastPC
    }
})
$form.Add_FormClosing({
    $script:searchTimer.Stop()
    $script:searchTimer.Dispose()
    $script:pingCheckTimer.Stop()
    $script:pingCheckTimer.Dispose()
    $script:pingRepeatTimer.Stop()
    $script:pingRepeatTimer.Dispose()
    if ($script:pinger) { $script:pinger.Dispose() }
    $script:infoFetchTimer.Stop()
    $script:infoFetchTimer.Dispose()
    if ($script:infoFetchPS) {
        try { $script:infoFetchPS.Stop() } catch { }
        $script:infoFetchPS.Dispose()
    }
    $script:logonFetchTimer.Stop()
    $script:logonFetchTimer.Dispose()
    $script:logonAutoRefreshTimer.Stop()
    $script:logonAutoRefreshTimer.Dispose()
    if ($script:logonFetchPS) {
        try { $script:logonFetchPS.Stop() } catch { }
        $script:logonFetchPS.Dispose()
    }
    Save-History
    Save-Favorites
    # Save window position for next launch
    $script:settings.Behavior.LastWindowX = $form.Location.X
    $script:settings.Behavior.LastWindowY = $form.Location.Y
    Save-Settings
    $script:toolTip.Dispose()
})

$form.ShowDialog() | Out-Null
$form.Dispose()
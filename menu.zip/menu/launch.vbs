Set objShell = CreateObject("WScript.Shell")
objShell.Run "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""C:\apps\menu\menu.ps1""", 0, False
